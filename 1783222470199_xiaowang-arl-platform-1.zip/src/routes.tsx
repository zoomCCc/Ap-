import type { ReactNode } from 'react';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import ForgotPasswordPage from './pages/ForgotPasswordPage';
import DashboardPage from './pages/DashboardPage';
import ModelsPage from './pages/ModelsPage';
import ApiKeysPage from './pages/ApiKeysPage';
import QuotaRecordsPage from './pages/QuotaRecordsPage';
import ApiLogsPage from './pages/ApiLogsPage';
import StatisticsPage from './pages/StatisticsPage';
import ProfilePage from './pages/ProfilePage';
import AdminPage from './pages/AdminPage';
import SettingsPage from './pages/SettingsPage';

export interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
  public?: boolean;
}

export const routes: RouteConfig[] = [
  { name: '登录', path: '/login', element: <LoginPage />, public: true },
  { name: '注册', path: '/register', element: <RegisterPage />, public: true },
  { name: '找回密码', path: '/forgot-password', element: <ForgotPasswordPage />, public: true },
  { name: '工作台', path: '/dashboard', element: <DashboardPage /> },
  { name: '模型中心', path: '/models', element: <ModelsPage /> },
  { name: 'API密钥', path: '/api-keys', element: <ApiKeysPage /> },
  { name: '消耗明细', path: '/quota-records', element: <QuotaRecordsPage /> },
  { name: 'API日志', path: '/api-logs', element: <ApiLogsPage /> },
  { name: '数据统计', path: '/statistics', element: <StatisticsPage /> },
  { name: '个人信息', path: '/profile', element: <ProfilePage /> },
  { name: '用户管理', path: '/admin', element: <AdminPage /> },
  { name: '设置', path: '/settings', element: <SettingsPage /> },
];

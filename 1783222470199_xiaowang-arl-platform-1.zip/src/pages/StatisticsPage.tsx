import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useApp } from '@/contexts/AppContext';
import { AppLayout } from '@/components/layouts/AppLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  getQuotaTrend, getCallTrend, getModelDistribution, getKeyDistribution,
  getApiKeys, getApiLogs, getFavorites
} from '@/services/api';
import { useAuth as useAuthContext } from '@/contexts/AuthContext';
import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend
} from 'recharts';
import { BarChart2, TrendingUp, Cpu, KeyRound } from 'lucide-react';

const CHART_COLORS = [
  'hsl(var(--chart-1))', 'hsl(var(--chart-2))', 'hsl(var(--chart-3))',
  'hsl(var(--chart-4))', 'hsl(var(--chart-5))',
  '#a78bfa', '#34d399', '#fb923c',
];

type TrendPeriod = '7' | '14' | '30';

export default function StatisticsPage() {
  const { user, profile } = useAuth();
  const { t } = useApp();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [trendPeriod, setTrendPeriod] = useState<TrendPeriod>('7');
  const [quotaTrend, setQuotaTrend] = useState<{ date: string; amount: number }[]>([]);
  const [callTrend, setCallTrend] = useState<{ date: string; count: number }[]>([]);
  const [modelDist, setModelDist] = useState<{ name: string; value: number }[]>([]);
  const [keyDist, setKeyDist] = useState<{ name: string; value: number }[]>([]);
  const [keyCount, setKeyCount] = useState(0);
  const [callCount, setCallCount] = useState(0);
  const [favCount, setFavCount] = useState(0);

  const loadTrend = async (days: number) => {
    if (!user) return;
    const [qt, ct] = await Promise.all([
      getQuotaTrend(user.id, days),
      getCallTrend(user.id, days),
    ]);
    setQuotaTrend(qt);
    setCallTrend(ct);
  };

  useEffect(() => {
    if (!user) { navigate('/login'); return; }
    const load = async () => {
      const [keys, logs, favs, modelD, keyD] = await Promise.all([
        getApiKeys(user.id),
        getApiLogs(user.id, undefined, undefined, undefined, undefined, undefined, 1, 1),
        getFavorites(user.id),
        getModelDistribution(user.id),
        getKeyDistribution(user.id),
      ]);
      setKeyCount(keys.length);
      setCallCount(logs.count);
      setFavCount(favs.length);
      setModelDist(modelD);
      setKeyDist(keyD);
      await loadTrend(7);
      setLoading(false);
    };
    load();
  }, [user]);

  useEffect(() => {
    loadTrend(Number(trendPeriod));
  }, [trendPeriod]);

  const remaining = (profile?.quota_total ?? 0) - (profile?.quota_used ?? 0);
  const usedPercent = profile ? Math.min(100, (profile.quota_used / profile.quota_total) * 100) : 0;

  const overviewCards = [
    { label: t('statistics.totalQuota'), value: (profile?.quota_total ?? 0).toLocaleString(), sub: '初始额度', icon: <TrendingUp size={14} /> },
    { label: t('statistics.usedQuota'), value: (profile?.quota_used ?? 0).toLocaleString(), sub: `已用 ${usedPercent.toFixed(1)}%`, icon: <TrendingUp size={14} /> },
    { label: t('statistics.remaining'), value: remaining.toLocaleString(), sub: '剩余可用', icon: <TrendingUp size={14} /> },
    { label: t('statistics.keyCount'), value: String(keyCount), sub: '活跃密钥', icon: <KeyRound size={14} /> },
    { label: t('statistics.callCount'), value: String(callCount), sub: '总调用次数', icon: <Cpu size={14} /> },
    { label: t('statistics.favoriteCount'), value: String(favCount), sub: '收藏模型', icon: <Cpu size={14} /> },
  ];

  const tooltipStyle = {
    contentStyle: {
      background: 'hsl(var(--background))',
      border: '1px solid hsl(var(--border))',
      borderRadius: '6px',
      fontSize: '12px',
    }
  };

  return (
    <AppLayout>
      <div className="max-w-5xl mx-auto space-y-5">
        <div>
          <h1 className="text-xl font-semibold text-foreground">{t('statistics.title')}</h1>
          <p className="text-sm text-muted-foreground mt-0.5">账户数据统计与使用报表</p>
        </div>

        {/* Overview */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          {overviewCards.map((c, i) => (
            <Card key={i} className="border-border">
              <CardContent className="p-3">
                {loading ? <Skeleton className="h-6 w-16 mb-1" /> : (
                  <div className="text-lg font-semibold text-foreground">{c.value}</div>
                )}
                <div className="text-xs text-muted-foreground">{c.label}</div>
                <div className="text-xs text-muted-foreground/60 mt-0.5">{c.sub}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Trend Charts */}
        <Card className="border-border">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <CardTitle className="text-sm font-medium">{t('statistics.trendTitle')}</CardTitle>
              <div className="flex gap-1">
                {(['7', '14', '30'] as TrendPeriod[]).map(d => (
                  <button key={d} onClick={() => setTrendPeriod(d)}
                    className={`px-2.5 py-1 text-xs rounded transition-colors ${
                      trendPeriod === d
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-muted text-muted-foreground hover:text-foreground'
                    }`}>
                    {d}天
                  </button>
                ))}
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {loading ? <Skeleton className="h-40 w-full" /> : (
              <ResponsiveContainer width="100%" height={160}>
                <AreaChart data={quotaTrend} margin={{ top: 4, right: 8, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="qGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.15} />
                      <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="date" tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }} />
                  <YAxis tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }} />
                  <Tooltip {...tooltipStyle} />
                  <Area type="monotone" dataKey="amount" name="消耗额度"
                    stroke="hsl(var(--primary))" fill="url(#qGrad)" strokeWidth={1.5} />
                </AreaChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        <Card className="border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">{t('statistics.callTrendTitle')}</CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? <Skeleton className="h-40 w-full" /> : (
              <ResponsiveContainer width="100%" height={160}>
                <BarChart data={callTrend} margin={{ top: 4, right: 8, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="date" tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }} />
                  <YAxis tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }} />
                  <Tooltip {...tooltipStyle} />
                  <Bar dataKey="count" name="调用次数" fill="hsl(var(--chart-2))" radius={[2, 2, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Model Distribution */}
          <Card className="border-border">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">{t('statistics.modelDistTitle')}</CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? <Skeleton className="h-44 w-full" /> : modelDist.length === 0 ? (
                <div className="h-44 flex items-center justify-center text-xs text-muted-foreground">暂无数据</div>
              ) : (
                <ResponsiveContainer width="100%" height={180}>
                  <PieChart>
                    <Pie data={modelDist} cx="50%" cy="50%" innerRadius={45} outerRadius={70}
                      dataKey="value" nameKey="name" paddingAngle={2}>
                      {modelDist.map((_, i) => (
                        <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip {...tooltipStyle} />
                    <Legend layout="horizontal" wrapperStyle={{ paddingTop: 8, fontSize: 11 }} />
                  </PieChart>
                </ResponsiveContainer>
              )}
            </CardContent>
          </Card>

          {/* Key Distribution */}
          <Card className="border-border">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">{t('statistics.keyDistTitle')}</CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? <Skeleton className="h-44 w-full" /> : keyDist.length === 0 ? (
                <div className="h-44 flex items-center justify-center text-xs text-muted-foreground">暂无数据</div>
              ) : (
                <ResponsiveContainer width="100%" height={180}>
                  <PieChart>
                    <Pie data={keyDist} cx="50%" cy="50%" innerRadius={45} outerRadius={70}
                      dataKey="value" nameKey="name" paddingAngle={2}>
                      {keyDist.map((_, i) => (
                        <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip {...tooltipStyle} />
                    <Legend layout="horizontal" wrapperStyle={{ paddingTop: 8, fontSize: 11 }} />
                  </PieChart>
                </ResponsiveContainer>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
}

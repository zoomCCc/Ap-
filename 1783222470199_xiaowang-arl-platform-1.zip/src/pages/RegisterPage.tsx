import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { supabase } from '@/db/supabase';
import { useApp } from '@/contexts/AppContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Checkbox } from '@/components/ui/checkbox';
import { toast } from 'sonner';
import { Mail, Phone, Eye, EyeOff, Gift, Loader2 } from 'lucide-react';

type RegisterType = 'email' | 'phone';

export default function RegisterPage() {
  const { t } = useApp();
  const navigate = useNavigate();
  const [type, setType] = useState<RegisterType>('email');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPwd, setConfirmPwd] = useState('');
  const [code, setCode] = useState('');
  const [agreed, setAgreed] = useState(false);
  const [showPwd, setShowPwd] = useState(false);
  const [codeSent, setCodeSent] = useState(false);
  const [countdown, setCountdown] = useState(0);
  const [loading, setLoading] = useState(false);
  const [sendingCode, setSendingCode] = useState(false);

  const startCountdown = () => {
    setCountdown(60);
    const timer = setInterval(() => {
      setCountdown(prev => {
        if (prev <= 1) { clearInterval(timer); return 0; }
        return prev - 1;
      });
    }, 1000);
  };

  const handleSendCode = async () => {
    if (!agreed) { toast.error(t('errors.agreeTerms')); return; }
    setSendingCode(true);
    try {
      if (type === 'email') {
        if (!email) { toast.error(t('auth.emailPlaceholder')); return; }
        const { error } = await supabase.auth.signInWithOtp({ email, options: { shouldCreateUser: false } });
        // For registration we use signUp
        if (error && !error.message.includes('not found')) {
          const { error: e2 } = await supabase.auth.signUp({ email, password: 'temp', options: { emailRedirectTo: undefined } });
          if (e2 && !e2.message.includes('already registered')) { toast.error(t('errors.codeSendFail')); return; }
        }
        // Send OTP for email registration
        const { error: otpErr } = await supabase.auth.signInWithOtp({ email });
        if (otpErr) { toast.error(t('errors.codeSendFail')); return; }
      } else {
        if (!phone) { toast.error(t('auth.phonePlaceholder')); return; }
        const formatted = phone.startsWith('+') ? phone : `+86${phone}`;
        const { error } = await supabase.auth.signInWithOtp({ phone: formatted });
        if (error) { toast.error(t('errors.codeSendFail')); return; }
      }
      setCodeSent(true);
      startCountdown();
      toast.success('验证码已发送');
    } finally {
      setSendingCode(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!agreed) { toast.error(t('errors.agreeTerms')); return; }
    if (password !== confirmPwd) { toast.error(t('errors.passwordMismatch')); return; }
    if (password.length < 8) { toast.error('密码至少8位'); return; }
    setLoading(true);
    try {
      if (type === 'email') {
        // Verify OTP first then register
        const { error } = await supabase.auth.verifyOtp({ email, token: code, type: 'email' });
        if (error) { toast.error(t('errors.codeWrong')); return; }
        // Now update password
        await supabase.auth.updateUser({ password });
      } else {
        const formatted = phone.startsWith('+') ? phone : `+86${phone}`;
        const { error } = await supabase.auth.verifyOtp({ phone: formatted, token: code, type: 'sms' });
        if (error) { toast.error(t('errors.codeWrong')); return; }
        await supabase.auth.updateUser({ password });
      }
      toast.success('注册成功，已获得1000万额度！');
      navigate('/dashboard');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-muted/30 p-4">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="mb-8 text-center">
          <h1 className="text-2xl font-semibold text-foreground">{t('appName')}</h1>
          <p className="text-sm text-muted-foreground mt-1">{t('appSubtitle')}</p>
        </div>

        <div className="bg-background border border-border rounded-lg p-6">
          {/* Gift badge */}
          <div className="flex items-center gap-2 bg-accent/50 text-accent-foreground px-3 py-2 rounded-md mb-5 text-xs">
            <Gift size={13} />
            <span>{t('auth.newUserGift')}</span>
          </div>

          <h2 className="text-lg font-medium mb-4">{t('auth.register')}</h2>

          <Tabs value={type} onValueChange={v => setType(v as RegisterType)} className="mb-4">
            <TabsList className="w-full">
              <TabsTrigger value="email" className="flex-1 gap-1.5">
                <Mail size={13} /> {t('auth.email')}
              </TabsTrigger>
              <TabsTrigger value="phone" className="flex-1 gap-1.5">
                <Phone size={13} /> {t('auth.phone')}
              </TabsTrigger>
            </TabsList>
          </Tabs>

          <form onSubmit={handleRegister} className="space-y-3">
            {type === 'email' ? (
              <div>
                <Label className="text-xs text-muted-foreground mb-1">{t('auth.email')}</Label>
                <Input
                  type="email" value={email} onChange={e => setEmail(e.target.value)}
                  placeholder={t('auth.emailPlaceholder')} required
                />
              </div>
            ) : (
              <div>
                <Label className="text-xs text-muted-foreground mb-1">{t('auth.phone')}</Label>
                <Input
                  type="tel" value={phone} onChange={e => setPhone(e.target.value)}
                  placeholder={t('auth.phonePlaceholder')} required
                />
              </div>
            )}

            {/* Verify Code Row */}
            <div>
              <Label className="text-xs text-muted-foreground mb-1">{t('auth.verifyCode')}</Label>
              <div className="flex gap-2">
                <Input
                  value={code} onChange={e => setCode(e.target.value)}
                  placeholder={t('auth.codePlaceholder')} required className="flex-1"
                />
                <Button
                  type="button" variant="outline" onClick={handleSendCode}
                  disabled={countdown > 0 || sendingCode} className="shrink-0 text-xs px-3"
                >
                  {sendingCode ? <Loader2 size={13} className="animate-spin" /> : countdown > 0 ? `${countdown}s` : t('auth.sendCode')}
                </Button>
              </div>
            </div>

            <div>
              <Label className="text-xs text-muted-foreground mb-1">{t('auth.password')}</Label>
              <div className="relative">
                <Input
                  type={showPwd ? 'text' : 'password'} value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder={t('auth.passwordPlaceholder')} required className="pr-10"
                />
                <button type="button" onClick={() => setShowPwd(!showPwd)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                  {showPwd ? <EyeOff size={14} /> : <Eye size={14} />}
                </button>
              </div>
            </div>

            <div>
              <Label className="text-xs text-muted-foreground mb-1">{t('auth.confirmPassword')}</Label>
              <Input
                type="password" value={confirmPwd}
                onChange={e => setConfirmPwd(e.target.value)}
                placeholder="请再次输入密码" required
              />
            </div>

            {/* Terms */}
            <div className="flex items-start gap-2 pt-1">
              <Checkbox
                id="terms" checked={agreed}
                onCheckedChange={v => setAgreed(Boolean(v))}
                className="mt-0.5"
              />
              <label htmlFor="terms" className="text-xs text-muted-foreground leading-relaxed cursor-pointer">
                {t('auth.agreeToTerms')}{' '}
                <span className="text-primary underline cursor-pointer">{t('auth.termsOfService')}</span>
                {' '}{t('auth.and')}{' '}
                <span className="text-primary underline cursor-pointer">{t('auth.privacyPolicy')}</span>
              </label>
            </div>

            <Button type="submit" className="w-full mt-2" disabled={loading || !codeSent}>
              {loading ? <Loader2 size={14} className="animate-spin mr-2" /> : null}
              {t('auth.register')}
            </Button>
          </form>

          <p className="text-center text-xs text-muted-foreground mt-4">
            {t('auth.hasAccount')}{' '}
            <Link to="/login" className="text-primary hover:underline">{t('auth.loginNow')}</Link>
          </p>
        </div>
      </div>
    </div>
  );
}

import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useApp } from '@/contexts/AppContext';
import { AppLayout } from '@/components/layouts/AppLayout';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { getApiLogs, getApiKeys } from '@/services/api';
import type { ApiLog, ApiKey } from '@/types/types';
import { ScrollText, Filter, CheckCircle2, XCircle } from 'lucide-react';

type Period = 'today' | 'week' | 'month' | 'custom';

function getPeriodDates(period: Period, customStart?: string, customEnd?: string) {
  const now = new Date();
  const end = new Date(now);
  end.setHours(23, 59, 59, 999);
  let start = new Date(now);

  if (period === 'today') {
    start.setHours(0, 0, 0, 0);
  } else if (period === 'week') {
    start.setDate(start.getDate() - 6);
    start.setHours(0, 0, 0, 0);
  } else if (period === 'month') {
    start.setDate(start.getDate() - 29);
    start.setHours(0, 0, 0, 0);
  } else {
    return {
      startDate: customStart ? `${customStart}T00:00:00` : undefined,
      endDate: customEnd ? `${customEnd}T23:59:59` : undefined,
    };
  }
  return { startDate: start.toISOString(), endDate: end.toISOString() };
}

export default function ApiLogsPage() {
  const { user } = useAuth();
  const { t } = useApp();
  const navigate = useNavigate();
  const [logs, setLogs] = useState<ApiLog[]>([]);
  const [apiKeys, setApiKeys] = useState<ApiKey[]>([]);
  const [loading, setLoading] = useState(true);
  const [count, setCount] = useState(0);
  const [page, setPage] = useState(1);
  const [period, setPeriod] = useState<Period>('week');
  const [customStart, setCustomStart] = useState('');
  const [customEnd, setCustomEnd] = useState('');
  const [filterKey, setFilterKey] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  const PAGE_SIZE = 20;

  const load = async (p = 1) => {
    if (!user) return;
    setLoading(true);
    const { startDate, endDate } = getPeriodDates(period, customStart, customEnd);
    const keyId = filterKey === 'all' ? undefined : filterKey;
    const status = filterStatus === 'all' ? undefined : filterStatus;
    const { data, count: total } = await getApiLogs(user.id, startDate, endDate, keyId, undefined, status, p, PAGE_SIZE);
    setLogs(data);
    setCount(total);
    setPage(p);
    setLoading(false);
  };

  useEffect(() => {
    if (!user) { navigate('/login'); return; }
    getApiKeys(user.id).then(setApiKeys);
    load(1);
  }, [user, period, filterKey, filterStatus]);

  return (
    <AppLayout>
      <div className="max-w-5xl mx-auto space-y-5">
        <div>
          <h1 className="text-xl font-semibold text-foreground">{t('apiLogs.title')}</h1>
          <p className="text-sm text-muted-foreground mt-0.5">查看API调用详细日志</p>
        </div>

        {/* Filters */}
        <div className="flex flex-col md:flex-row gap-3 flex-wrap">
          <div className="flex gap-1">
            {(['today', 'week', 'month', 'custom'] as Period[]).map(p => (
              <button
                key={p}
                onClick={() => setPeriod(p)}
                className={`px-3 py-1.5 text-xs rounded-md transition-colors ${
                  period === p
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-muted text-muted-foreground hover:text-foreground'
                }`}
              >
                {t(`quotaRecords.filter.${p}`)}
              </button>
            ))}
          </div>

          {period === 'custom' && (
            <div className="flex gap-2 items-center">
              <Input type="date" value={customStart} onChange={e => setCustomStart(e.target.value)} className="h-8 text-xs w-36" />
              <span className="text-muted-foreground text-xs">至</span>
              <Input type="date" value={customEnd} onChange={e => setCustomEnd(e.target.value)} className="h-8 text-xs w-36" />
              <Button size="sm" onClick={() => load(1)}>
                <Filter size={12} className="mr-1" /> 筛选
              </Button>
            </div>
          )}

          <div className="flex gap-2 md:ml-auto">
            <select
              value={filterKey}
              onChange={e => setFilterKey(e.target.value)}
              className="h-9 px-3 rounded-md border border-border bg-background text-sm text-foreground"
            >
              <option value="all">全部密钥</option>
              {apiKeys.map(k => <option key={k.id} value={k.id}>{k.name}</option>)}
            </select>
            <select
              value={filterStatus}
              onChange={e => setFilterStatus(e.target.value)}
              className="h-9 px-3 rounded-md border border-border bg-background text-sm text-foreground"
            >
              <option value="all">全部状态</option>
              <option value="success">{t('apiLogs.success')}</option>
              <option value="failed">{t('apiLogs.failed')}</option>
            </select>
          </div>
        </div>

        {/* Table */}
        <Card className="border-border min-w-0">
          <CardContent className="p-0">
            {loading ? (
              <div className="p-4 space-y-3">
                {Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-10 w-full" />)}
              </div>
            ) : logs.length === 0 ? (
              <div className="py-16 text-center">
                <ScrollText size={28} className="mx-auto mb-3 text-muted-foreground opacity-30" />
                <p className="text-sm text-muted-foreground">{t('apiLogs.empty')}</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full min-w-max">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="text-left p-4 text-xs text-muted-foreground font-normal whitespace-nowrap">{t('apiLogs.time')}</th>
                      <th className="text-left p-4 text-xs text-muted-foreground font-normal whitespace-nowrap">{t('apiLogs.apiKey')}</th>
                      <th className="text-left p-4 text-xs text-muted-foreground font-normal whitespace-nowrap">{t('apiLogs.model')}</th>
                      <th className="text-left p-4 text-xs text-muted-foreground font-normal whitespace-nowrap">{t('apiLogs.status')}</th>
                      <th className="text-left p-4 text-xs text-muted-foreground font-normal whitespace-nowrap">{t('apiLogs.quota')}</th>
                      <th className="text-left p-4 text-xs text-muted-foreground font-normal whitespace-nowrap">{t('apiLogs.request')}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {logs.map(log => (
                      <tr key={log.id} className="border-b border-border/50 hover:bg-muted/30 transition-colors">
                        <td className="p-4 text-xs text-muted-foreground whitespace-nowrap">
                          {new Date(log.created_at).toLocaleString('zh-CN', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' })}
                        </td>
                        <td className="p-4 text-xs text-foreground whitespace-nowrap">{log.api_key_name || '—'}</td>
                        <td className="p-4 text-xs text-foreground whitespace-nowrap">{log.model_name || '—'}</td>
                        <td className="p-4 whitespace-nowrap">
                          {log.response_status === 'success' ? (
                            <div className="flex items-center gap-1 text-xs text-green-600">
                              <CheckCircle2 size={12} /> {t('apiLogs.success')}
                            </div>
                          ) : (
                            <div className="flex items-center gap-1 text-xs text-destructive">
                              <XCircle size={12} /> {t('apiLogs.failed')}
                            </div>
                          )}
                        </td>
                        <td className="p-4 text-xs text-foreground whitespace-nowrap">
                          {log.quota_used.toFixed(2)}
                        </td>
                        <td className="p-4 text-xs text-muted-foreground max-w-xs truncate">
                          {log.request_summary || '—'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>

        {count > PAGE_SIZE && (
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>{t('common.totalItems', { n: count })}</span>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => load(page - 1)}>上一页</Button>
              <span className="px-3 py-1.5">第 {page} 页</span>
              <Button variant="outline" size="sm" disabled={page * PAGE_SIZE >= count} onClick={() => load(page + 1)}>下一页</Button>
            </div>
          </div>
        )}
      </div>
    </AppLayout>
  );
}

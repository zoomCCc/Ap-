import React, { useEffect, useState, useMemo } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useApp } from '@/contexts/AppContext';
import { AppLayout } from '@/components/layouts/AppLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle
} from '@/components/ui/dialog';
import { toast } from 'sonner';
import { getModels, getFavorites, addFavorite, removeFavorite } from '@/services/api';
import type { Model } from '@/types/types';
import {
  Search, Heart, HeartOff, SlidersHorizontal, Star, ChevronRight,
  ArrowLeft, X, GitCompare, Cpu
} from 'lucide-react';

type View = 'list' | 'detail' | 'favorites' | 'compare';

export default function ModelsPage() {
  const { user } = useAuth();
  const { t } = useApp();
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();

  const [models, setModels] = useState<Model[]>([]);
  const [favoriteIds, setFavoriteIds] = useState<Set<string>>(new Set());
  const [compareIds, setCompareIds] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState<View>('list');
  const [selectedModel, setSelectedModel] = useState<Model | null>(null);
  const [search, setSearch] = useState('');
  const [filterCategory, setFilterCategory] = useState('all');
  const [filterProvider, setFilterProvider] = useState('all');

  useEffect(() => {
    if (!user) { navigate('/login'); return; }
    const load = async () => {
      const [allModels, favs] = await Promise.all([
        getModels(),
        getFavorites(user.id),
      ]);
      setModels(allModels);
      setFavoriteIds(new Set(favs.map(f => f.model_id)));
      setLoading(false);
    };
    load();
  }, [user, navigate]);

  const categories = useMemo(() => {
    const cats = [...new Set(models.map(m => m.category))];
    return cats;
  }, [models]);

  const providers = useMemo(() => {
    const provs = [...new Set(models.map(m => m.provider))];
    return provs;
  }, [models]);

  const filteredModels = useMemo(() => {
    return models.filter(m => {
      const matchSearch = !search || m.name.toLowerCase().includes(search.toLowerCase()) ||
        m.provider.toLowerCase().includes(search.toLowerCase()) ||
        (m.description || '').toLowerCase().includes(search.toLowerCase());
      const matchCat = filterCategory === 'all' || m.category === filterCategory;
      const matchProv = filterProvider === 'all' || m.provider === filterProvider;
      return matchSearch && matchCat && matchProv;
    });
  }, [models, search, filterCategory, filterProvider]);

  const favoriteModels = useMemo(() =>
    models.filter(m => favoriteIds.has(m.id)), [models, favoriteIds]);

  const compareModels = useMemo(() =>
    models.filter(m => compareIds.has(m.id)), [models, compareIds]);

  const handleFavorite = async (model: Model, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!user) return;
    if (favoriteIds.has(model.id)) {
      await removeFavorite(user.id, model.id);
      setFavoriteIds(prev => { const s = new Set(prev); s.delete(model.id); return s; });
      toast.success('已取消收藏');
    } else {
      await addFavorite(user.id, model.id);
      setFavoriteIds(prev => new Set([...prev, model.id]));
      toast.success('已收藏');
    }
  };

  const handleCompare = (model: Model, e: React.MouseEvent) => {
    e.stopPropagation();
    if (compareIds.has(model.id)) {
      setCompareIds(prev => { const s = new Set(prev); s.delete(model.id); return s; });
    } else {
      if (compareIds.size >= 5) { toast.error(t('models.maxCompare')); return; }
      setCompareIds(prev => new Set([...prev, model.id]));
      toast.success('已加入对比');
    }
  };

  const providerColors: Record<string, string> = {
    'OpenAI': 'bg-emerald-50 text-emerald-700 border-emerald-200',
    'Anthropic': 'bg-orange-50 text-orange-700 border-orange-200',
    'Google': 'bg-blue-50 text-blue-700 border-blue-200',
    '百度': 'bg-sky-50 text-sky-700 border-sky-200',
    '阿里云': 'bg-amber-50 text-amber-700 border-amber-200',
    '科大讯飞': 'bg-indigo-50 text-indigo-700 border-indigo-200',
    '智谱AI': 'bg-violet-50 text-violet-700 border-violet-200',
    'Moonshot': 'bg-slate-50 text-slate-700 border-slate-200',
    'DeepSeek': 'bg-teal-50 text-teal-700 border-teal-200',
    'Meta': 'bg-blue-50 text-blue-700 border-blue-200',
    'Mistral': 'bg-rose-50 text-rose-700 border-rose-200',
    'xAI': 'bg-gray-50 text-gray-700 border-gray-200',
    'MiniMax': 'bg-purple-50 text-purple-700 border-purple-200',
    '零一万物': 'bg-green-50 text-green-700 border-green-200',
    'Cohere': 'bg-cyan-50 text-cyan-700 border-cyan-200',
  };

  const ModelCard = ({ model }: { model: Model }) => (
    <Card
      className="border-border cursor-pointer hover:border-primary/40 transition-all group h-full flex flex-col"
      onClick={() => { setSelectedModel(model); setView('detail'); }}
    >
      <CardContent className="p-4 flex flex-col h-full">
        <div className="flex items-start justify-between gap-2 mb-2">
          <div className="flex-1 min-w-0">
            <h3 className="text-sm font-medium text-foreground truncate">{model.name}</h3>
            <span className={`inline-block text-xs px-2 py-0.5 rounded border mt-1 ${providerColors[model.provider] || 'bg-muted text-muted-foreground border-border'}`}>
              {model.provider}
            </span>
          </div>
          <button
            onClick={e => handleFavorite(model, e)}
            className="text-muted-foreground hover:text-primary transition-colors shrink-0 p-1 -mr-1 -mt-1"
          >
            {favoriteIds.has(model.id)
              ? <Heart size={15} className="fill-primary text-primary" />
              : <Heart size={15} />
            }
          </button>
        </div>

        <p className="text-xs text-muted-foreground flex-1 line-clamp-2 mb-3">
          {model.description || '暂无描述'}
        </p>

        <div className="flex flex-wrap gap-1 mb-3">
          {(model.tags || []).slice(0, 3).map(tag => (
            <span key={tag} className="text-xs px-1.5 py-0.5 bg-muted text-muted-foreground rounded">
              {tag}
            </span>
          ))}
        </div>

        <div className="flex items-center gap-1.5 pt-1 border-t border-border">
          <Badge variant="outline" className="text-xs">{model.category}</Badge>
          <button
            onClick={e => handleCompare(model, e)}
            className={`ml-auto text-xs flex items-center gap-1 px-2 py-1 rounded transition-colors ${
              compareIds.has(model.id)
                ? 'bg-primary text-primary-foreground'
                : 'text-muted-foreground hover:text-foreground hover:bg-muted'
            }`}
          >
            <GitCompare size={11} />
            {compareIds.has(model.id) ? '已选' : '对比'}
          </button>
        </div>
      </CardContent>
    </Card>
  );

  const renderContent = () => {
    if (view === 'detail' && selectedModel) {
      return (
        <div className="max-w-2xl mx-auto space-y-4">
          <button onClick={() => { setView('list'); setSelectedModel(null); }}
            className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors">
            <ArrowLeft size={15} /> {t('models.backToList')}
          </button>
          <Card className="border-border">
            <CardContent className="p-6">
              <div className="flex items-start justify-between gap-3 mb-4">
                <div>
                  <h2 className="text-xl font-semibold text-foreground">{selectedModel.name}</h2>
                  <span className={`inline-block text-xs px-2 py-0.5 rounded border mt-1 ${providerColors[selectedModel.provider] || 'bg-muted text-muted-foreground border-border'}`}>
                    {selectedModel.provider}
                  </span>
                </div>
                <button onClick={e => handleFavorite(selectedModel, e)}
                  className="text-muted-foreground hover:text-primary transition-colors p-1">
                  {favoriteIds.has(selectedModel.id)
                    ? <Heart size={20} className="fill-primary text-primary" />
                    : <Heart size={20} />}
                </button>
              </div>

              <div className="space-y-3 text-sm">
                <div>
                  <span className="text-xs text-muted-foreground uppercase tracking-wide">{t('models.category')}</span>
                  <p className="text-foreground mt-0.5">{selectedModel.category}</p>
                </div>
                <div>
                  <span className="text-xs text-muted-foreground uppercase tracking-wide">描述</span>
                  <p className="text-foreground mt-0.5 leading-relaxed">{selectedModel.description || '暂无描述'}</p>
                </div>
                <div>
                  <span className="text-xs text-muted-foreground uppercase tracking-wide">{t('models.tags')}</span>
                  <div className="flex flex-wrap gap-1.5 mt-1">
                    {(selectedModel.tags || []).map(tag => (
                      <span key={tag} className="text-xs px-2 py-1 bg-muted text-muted-foreground rounded">{tag}</span>
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex gap-2 mt-5 pt-4 border-t border-border">
                <Button
                  variant="outline" size="sm"
                  onClick={e => handleCompare(selectedModel, e)}
                  className={compareIds.has(selectedModel.id) ? 'bg-primary text-primary-foreground border-primary' : ''}
                >
                  <GitCompare size={13} className="mr-1.5" />
                  {compareIds.has(selectedModel.id) ? '已加入对比' : t('models.compare')}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      );
    }

    if (view === 'favorites') {
      return (
        <div className="space-y-4">
          {favoriteModels.length === 0 ? (
            <div className="text-center py-16 text-muted-foreground">
              <Heart size={32} className="mx-auto mb-3 opacity-30" />
              <p>{t('models.noFavorites')}</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {favoriteModels.map(m => <ModelCard key={m.id} model={m} />)}
            </div>
          )}
        </div>
      );
    }

    if (view === 'compare') {
      if (compareModels.length < 2) {
        return (
          <div className="text-center py-16 text-muted-foreground">
            <GitCompare size={32} className="mx-auto mb-3 opacity-30" />
            <p>{t('models.minCompare')}</p>
            <Button variant="outline" size="sm" className="mt-4" onClick={() => setView('list')}>
              返回选择模型
            </Button>
          </div>
        );
      }
      const fields = [
        { label: t('models.provider'), key: 'provider' as keyof Model },
        { label: t('models.category'), key: 'category' as keyof Model },
        { label: '描述', key: 'description' as keyof Model },
      ];
      return (
        <div className="space-y-4">
          <div className="overflow-x-auto">
            <table className="w-full min-w-max text-sm border-collapse">
              <thead>
                <tr>
                  <th className="text-left p-3 border-b border-border text-muted-foreground font-normal text-xs whitespace-nowrap w-24">属性</th>
                  {compareModels.map(m => (
                    <th key={m.id} className="text-left p-3 border-b border-border whitespace-nowrap">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-foreground">{m.name}</span>
                        <button onClick={() => setCompareIds(prev => { const s = new Set(prev); s.delete(m.id); return s; })}
                          className="text-muted-foreground hover:text-foreground">
                          <X size={12} />
                        </button>
                      </div>
                      <span className={`text-xs px-1.5 py-0.5 rounded border ${providerColors[m.provider] || 'bg-muted text-muted-foreground border-border'}`}>
                        {m.provider}
                      </span>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {fields.map(f => (
                  <tr key={f.key} className="border-b border-border/50">
                    <td className="p-3 text-xs text-muted-foreground whitespace-nowrap">{f.label}</td>
                    {compareModels.map(m => (
                      <td key={m.id} className="p-3 text-sm text-foreground">
                        {String(m[f.key] || '—')}
                      </td>
                    ))}
                  </tr>
                ))}
                <tr>
                  <td className="p-3 text-xs text-muted-foreground whitespace-nowrap">{t('models.tags')}</td>
                  {compareModels.map(m => (
                    <td key={m.id} className="p-3">
                      <div className="flex flex-wrap gap-1">
                        {(m.tags || []).map(tag => (
                          <span key={tag} className="text-xs px-1.5 py-0.5 bg-muted text-muted-foreground rounded">{tag}</span>
                        ))}
                      </div>
                    </td>
                  ))}
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      );
    }

    // List view
    return (
      <div className="space-y-4">
        {/* Filters */}
        <div className="flex flex-col md:flex-row gap-3">
          <div className="relative flex-1 min-w-0">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input value={search} onChange={e => setSearch(e.target.value)}
              placeholder={t('models.searchPlaceholder')} className="pl-9" />
          </div>
          <select
            value={filterCategory}
            onChange={e => setFilterCategory(e.target.value)}
            className="h-9 px-3 rounded-md border border-border bg-background text-sm text-foreground"
          >
            <option value="all">{t('models.allCategories')}</option>
            {categories.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
          <select
            value={filterProvider}
            onChange={e => setFilterProvider(e.target.value)}
            className="h-9 px-3 rounded-md border border-border bg-background text-sm text-foreground"
          >
            <option value="all">{t('models.allProviders')}</option>
            {providers.map(p => <option key={p} value={p}>{p}</option>)}
          </select>
        </div>

        <div className="text-xs text-muted-foreground">共 {filteredModels.length} 个模型</div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {Array.from({ length: 9 }).map((_, i) => (
              <Skeleton key={i} className="h-40 rounded-lg" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {filteredModels.map(m => <ModelCard key={m.id} model={m} />)}
          </div>
        )}
      </div>
    );
  };

  return (
    <AppLayout>
      <div className="max-w-6xl mx-auto space-y-5">
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div>
            <h1 className="text-xl font-semibold text-foreground">{t('models.title')}</h1>
            <p className="text-sm text-muted-foreground mt-0.5">{t('models.subtitle')}</p>
          </div>
          {compareIds.size > 0 && (
            <div className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground">
                {t('models.compareHint', { n: compareIds.size })}
              </span>
              <Button size="sm" onClick={() => setView('compare')}>
                <GitCompare size={13} className="mr-1.5" /> {t('models.startCompare')}
              </Button>
              <Button size="sm" variant="outline" onClick={() => setCompareIds(new Set())}>
                {t('models.clearCompare')}
              </Button>
            </div>
          )}
        </div>

        <div className="flex gap-1 border-b border-border pb-1">
          {([
            ['list', <Cpu size={13} />, t('models.title')],
            ['favorites', <Heart size={13} />, t('models.myFavorites')],
            ['compare', <GitCompare size={13} />, t('models.compareModels')],
          ] as [View, React.ReactNode, string][]).map(([v, icon, label]) => (
            <button
              key={v}
              onClick={() => setView(v)}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-sm rounded-md transition-colors ${
                view === v
                  ? 'text-primary font-medium border-b-2 border-primary rounded-b-none'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              {icon}{label}
              {v === 'favorites' && favoriteIds.size > 0 && (
                <span className="ml-1 text-xs bg-muted px-1.5 py-0.5 rounded-full">{favoriteIds.size}</span>
              )}
            </button>
          ))}
        </div>

        {renderContent()}
      </div>
    </AppLayout>
  );
}

import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { supabase } from '@/db/supabase';
import { useApp } from '@/contexts/AppContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import { Mail, Phone, Eye, EyeOff, KeyRound, Loader2 } from 'lucide-react';

type LoginType = 'emailOtp' | 'phoneOtp' | 'emailPassword' | 'phonePassword';

export default function LoginPage() {
  const { t } = useApp();
  const navigate = useNavigate();
  const [loginType, setLoginType] = useState<LoginType>('emailOtp');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [code, setCode] = useState('');
  const [showPwd, setShowPwd] = useState(false);
  const [codeSent, setCodeSent] = useState(false);
  const [countdown, setCountdown] = useState(0);
  const [loading, setLoading] = useState(false);
  const [sendingCode, setSendingCode] = useState(false);

  const startCountdown = () => {
    setCountdown(60);
    const timer = setInterval(() => {
      setCountdown(prev => { if (prev <= 1) { clearInterval(timer); return 0; } return prev - 1; });
    }, 1000);
  };

  const isOtp = loginType === 'emailOtp' || loginType === 'phoneOtp';
  const isEmail = loginType === 'emailOtp' || loginType === 'emailPassword';

  const handleSendCode = async () => {
    setSendingCode(true);
    try {
      if (loginType === 'emailOtp') {
        if (!email) { toast.error(t('auth.emailPlaceholder')); return; }
        const { error } = await supabase.auth.signInWithOtp({ email });
        if (error) { toast.error(t('errors.codeSendFail')); return; }
      } else {
        if (!phone) { toast.error(t('auth.phonePlaceholder')); return; }
        const formatted = phone.startsWith('+') ? phone : `+86${phone}`;
        const { error } = await supabase.auth.signInWithOtp({ phone: formatted });
        if (error) { toast.error(t('errors.codeSendFail')); return; }
      }
      setCodeSent(true);
      startCountdown();
      toast.success('验证码已发送');
    } finally {
      setSendingCode(false);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (loginType === 'emailOtp') {
        const { error } = await supabase.auth.verifyOtp({ email, token: code, type: 'email' });
        if (error) { toast.error(t('errors.codeWrong')); return; }
      } else if (loginType === 'phoneOtp') {
        const formatted = phone.startsWith('+') ? phone : `+86${phone}`;
        const { error } = await supabase.auth.verifyOtp({ phone: formatted, token: code, type: 'sms' });
        if (error) { toast.error(t('errors.codeWrong')); return; }
      } else if (loginType === 'emailPassword') {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) { toast.error(t('errors.wrongPassword')); return; }
      } else {
        const formatted = phone.startsWith('+') ? phone : `+86${phone}`;
        // phone+password: use phone as email-like identifier
        const emailLike = `${formatted.replace('+', '')}@phone.miaoda.com`;
        const { error } = await supabase.auth.signInWithPassword({ email: emailLike, password });
        if (error) { toast.error(t('errors.wrongPassword')); return; }
      }
      toast.success('登录成功');
      navigate('/dashboard');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-muted/30 p-4">
      <div className="w-full max-w-md">
        <div className="mb-8 text-center">
          <h1 className="text-2xl font-semibold text-foreground">{t('appName')}</h1>
          <p className="text-sm text-muted-foreground mt-1">{t('appSubtitle')}</p>
        </div>

        <div className="bg-background border border-border rounded-lg p-6">
          <h2 className="text-lg font-medium mb-4">{t('auth.login')}</h2>

          {/* Method selector */}
          <div className="grid grid-cols-2 gap-1.5 mb-4">
            {([ 
              ['emailOtp', <Mail size={13} />, t('auth.emailOtp')],
              ['phoneOtp', <Phone size={13} />, t('auth.phoneOtp')],
              ['emailPassword', <Mail size={13} />, t('auth.emailPassword')],
              ['phonePassword', <Phone size={13} />, t('auth.phonePassword')],
            ] as [LoginType, React.ReactNode, string][]).map(([val, icon, label]) => (
              <button
                key={val}
                type="button"
                onClick={() => { setLoginType(val); setCodeSent(false); setCountdown(0); }}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded border text-xs transition-colors ${
                  loginType === val
                    ? 'border-primary bg-accent text-primary font-medium'
                    : 'border-border text-muted-foreground hover:text-foreground hover:bg-muted'
                }`}
              >
                {icon}{label}
              </button>
            ))}
          </div>

          <form onSubmit={handleLogin} className="space-y-3">
            {isEmail ? (
              <div>
                <Label className="text-xs text-muted-foreground mb-1">{t('auth.email')}</Label>
                <Input type="email" value={email} onChange={e => setEmail(e.target.value)}
                  placeholder={t('auth.emailPlaceholder')} required />
              </div>
            ) : (
              <div>
                <Label className="text-xs text-muted-foreground mb-1">{t('auth.phone')}</Label>
                <Input type="tel" value={phone} onChange={e => setPhone(e.target.value)}
                  placeholder={t('auth.phonePlaceholder')} required />
              </div>
            )}

            {isOtp ? (
              <div>
                <Label className="text-xs text-muted-foreground mb-1">{t('auth.verifyCode')}</Label>
                <div className="flex gap-2">
                  <Input value={code} onChange={e => setCode(e.target.value)}
                    placeholder={t('auth.codePlaceholder')} required className="flex-1" />
                  <Button type="button" variant="outline" onClick={handleSendCode}
                    disabled={countdown > 0 || sendingCode} className="shrink-0 text-xs px-3">
                    {sendingCode ? <Loader2 size={13} className="animate-spin" /> : countdown > 0 ? `${countdown}s` : t('auth.sendCode')}
                  </Button>
                </div>
              </div>
            ) : (
              <div>
                <Label className="text-xs text-muted-foreground mb-1">{t('auth.password')}</Label>
                <div className="relative">
                  <Input type={showPwd ? 'text' : 'password'} value={password}
                    onChange={e => setPassword(e.target.value)}
                    placeholder={t('auth.passwordPlaceholder')} required className="pr-10" />
                  <button type="button" onClick={() => setShowPwd(!showPwd)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                    {showPwd ? <EyeOff size={14} /> : <Eye size={14} />}
                  </button>
                </div>
              </div>
            )}

            <div className="flex items-center justify-between pt-0.5">
              <Link to="/forgot-password" className="text-xs text-muted-foreground hover:text-primary">
                {t('auth.forgotPassword')}
              </Link>
            </div>

            <Button type="submit" className="w-full" disabled={loading || (isOtp && !codeSent)}>
              {loading ? <Loader2 size={14} className="animate-spin mr-2" /> : <KeyRound size={14} className="mr-2" />}
              {t('auth.login')}
            </Button>
          </form>

          <p className="text-center text-xs text-muted-foreground mt-4">
            {t('auth.noAccount')}{' '}
            <Link to="/register" className="text-primary hover:underline">{t('auth.registerNow')}</Link>
          </p>
        </div>
      </div>
    </div>
  );
}

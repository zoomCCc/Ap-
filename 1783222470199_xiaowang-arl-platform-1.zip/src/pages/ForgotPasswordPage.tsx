import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { supabase } from '@/db/supabase';
import { useApp } from '@/contexts/AppContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import { Mail, Phone, Eye, EyeOff, Loader2, ArrowLeft } from 'lucide-react';

type ResetType = 'email' | 'phone';
type Step = 'send' | 'verify';

export default function ForgotPasswordPage() {
  const { t } = useApp();
  const navigate = useNavigate();
  const [type, setType] = useState<ResetType>('email');
  const [step, setStep] = useState<Step>('send');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [code, setCode] = useState('');
  const [newPwd, setNewPwd] = useState('');
  const [confirmPwd, setConfirmPwd] = useState('');
  const [showPwd, setShowPwd] = useState(false);
  const [countdown, setCountdown] = useState(0);
  const [loading, setLoading] = useState(false);
  const [sendingCode, setSendingCode] = useState(false);

  const startCountdown = () => {
    setCountdown(60);
    const timer = setInterval(() => {
      setCountdown(prev => { if (prev <= 1) { clearInterval(timer); return 0; } return prev - 1; });
    }, 1000);
  };

  const handleSendCode = async () => {
    setSendingCode(true);
    try {
      if (type === 'email') {
        if (!email) { toast.error(t('auth.emailPlaceholder')); return; }
        const { error } = await supabase.auth.signInWithOtp({ email });
        if (error) { toast.error(t('errors.codeSendFail')); return; }
      } else {
        if (!phone) { toast.error(t('auth.phonePlaceholder')); return; }
        const formatted = phone.startsWith('+') ? phone : `+86${phone}`;
        const { error } = await supabase.auth.signInWithOtp({ phone: formatted });
        if (error) { toast.error(t('errors.codeSendFail')); return; }
      }
      startCountdown();
      setStep('verify');
      toast.success('验证码已发送');
    } finally {
      setSendingCode(false);
    }
  };

  const handleReset = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPwd !== confirmPwd) { toast.error(t('errors.passwordMismatch')); return; }
    if (newPwd.length < 8) { toast.error('密码至少8位'); return; }
    setLoading(true);
    try {
      let verifyErr;
      if (type === 'email') {
        const { error } = await supabase.auth.verifyOtp({ email, token: code, type: 'email' });
        verifyErr = error;
      } else {
        const formatted = phone.startsWith('+') ? phone : `+86${phone}`;
        const { error } = await supabase.auth.verifyOtp({ phone: formatted, token: code, type: 'sms' });
        verifyErr = error;
      }
      if (verifyErr) { toast.error(t('errors.codeWrong')); return; }
      const { error } = await supabase.auth.updateUser({ password: newPwd });
      if (error) { toast.error('密码重置失败，请重试'); return; }
      toast.success('密码重置成功，请重新登录');
      navigate('/login');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-muted/30 p-4">
      <div className="w-full max-w-md">
        <div className="mb-8 text-center">
          <h1 className="text-2xl font-semibold text-foreground">{t('appName')}</h1>
          <p className="text-sm text-muted-foreground mt-1">{t('appSubtitle')}</p>
        </div>

        <div className="bg-background border border-border rounded-lg p-6">
          <div className="flex items-center gap-2 mb-4">
            <Link to="/login" className="text-muted-foreground hover:text-foreground">
              <ArrowLeft size={16} />
            </Link>
            <h2 className="text-lg font-medium">{t('auth.forgotPassword')}</h2>
          </div>

          <Tabs value={type} onValueChange={v => { setType(v as ResetType); setStep('send'); }} className="mb-4">
            <TabsList className="w-full">
              <TabsTrigger value="email" className="flex-1 gap-1.5">
                <Mail size={13} /> {t('auth.email')}
              </TabsTrigger>
              <TabsTrigger value="phone" className="flex-1 gap-1.5">
                <Phone size={13} /> {t('auth.phone')}
              </TabsTrigger>
            </TabsList>
          </Tabs>

          {step === 'send' ? (
            <div className="space-y-3">
              {type === 'email' ? (
                <div>
                  <Label className="text-xs text-muted-foreground mb-1">{t('auth.email')}</Label>
                  <Input type="email" value={email} onChange={e => setEmail(e.target.value)}
                    placeholder={t('auth.emailPlaceholder')} />
                </div>
              ) : (
                <div>
                  <Label className="text-xs text-muted-foreground mb-1">{t('auth.phone')}</Label>
                  <Input type="tel" value={phone} onChange={e => setPhone(e.target.value)}
                    placeholder={t('auth.phonePlaceholder')} />
                </div>
              )}
              <Button className="w-full" onClick={handleSendCode} disabled={sendingCode}>
                {sendingCode ? <Loader2 size={14} className="animate-spin mr-2" /> : null}
                {t('auth.sendCode')}
              </Button>
            </div>
          ) : (
            <form onSubmit={handleReset} className="space-y-3">
              <div>
                <Label className="text-xs text-muted-foreground mb-1">{t('auth.verifyCode')}</Label>
                <div className="flex gap-2">
                  <Input value={code} onChange={e => setCode(e.target.value)}
                    placeholder={t('auth.codePlaceholder')} required className="flex-1" />
                  <Button type="button" variant="outline" onClick={handleSendCode}
                    disabled={countdown > 0 || sendingCode} className="shrink-0 text-xs px-3">
                    {countdown > 0 ? `${countdown}s` : t('auth.resendCode')}
                  </Button>
                </div>
              </div>
              <div>
                <Label className="text-xs text-muted-foreground mb-1">{t('auth.newPassword')}</Label>
                <div className="relative">
                  <Input type={showPwd ? 'text' : 'password'} value={newPwd}
                    onChange={e => setNewPwd(e.target.value)}
                    placeholder={t('auth.passwordPlaceholder')} required className="pr-10" />
                  <button type="button" onClick={() => setShowPwd(!showPwd)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                    {showPwd ? <EyeOff size={14} /> : <Eye size={14} />}
                  </button>
                </div>
              </div>
              <div>
                <Label className="text-xs text-muted-foreground mb-1">{t('auth.confirmPassword')}</Label>
                <Input type="password" value={confirmPwd}
                  onChange={e => setConfirmPwd(e.target.value)}
                  placeholder="请再次输入新密码" required />
              </div>
              <Button type="submit" className="w-full" disabled={loading}>
                {loading ? <Loader2 size={14} className="animate-spin mr-2" /> : null}
                {t('auth.resetPassword')}
              </Button>
            </form>
          )}

          <p className="text-center text-xs text-muted-foreground mt-4">
            <Link to="/login" className="text-primary hover:underline">{t('auth.backToLogin')}</Link>
          </p>
        </div>
      </div>
    </div>
  );
}

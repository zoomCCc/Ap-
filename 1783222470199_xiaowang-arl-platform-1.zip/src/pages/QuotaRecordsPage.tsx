import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useApp } from '@/contexts/AppContext';
import { AppLayout } from '@/components/layouts/AppLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { getQuotaRecords, getApiKeys } from '@/services/api';
import type { QuotaRecord, ApiKey } from '@/types/types';
import { FileText, Filter } from 'lucide-react';

type Period = 'today' | 'week' | 'month' | 'custom';

function getPeriodDates(period: Period, customStart?: string, customEnd?: string) {
  const now = new Date();
  const end = new Date(now);
  end.setHours(23, 59, 59, 999);
  let start = new Date(now);

  if (period === 'today') {
    start.setHours(0, 0, 0, 0);
  } else if (period === 'week') {
    start.setDate(start.getDate() - 6);
    start.setHours(0, 0, 0, 0);
  } else if (period === 'month') {
    start.setDate(start.getDate() - 29);
    start.setHours(0, 0, 0, 0);
  } else {
    return {
      startDate: customStart ? `${customStart}T00:00:00` : undefined,
      endDate: customEnd ? `${customEnd}T23:59:59` : undefined,
    };
  }
  return { startDate: start.toISOString(), endDate: end.toISOString() };
}

export default function QuotaRecordsPage() {
  const { user } = useAuth();
  const { t } = useApp();
  const navigate = useNavigate();
  const [records, setRecords] = useState<QuotaRecord[]>([]);
  const [apiKeys, setApiKeys] = useState<ApiKey[]>([]);
  const [loading, setLoading] = useState(true);
  const [count, setCount] = useState(0);
  const [page, setPage] = useState(1);
  const [period, setPeriod] = useState<Period>('week');
  const [customStart, setCustomStart] = useState('');
  const [customEnd, setCustomEnd] = useState('');
  const [filterKey, setFilterKey] = useState('all');
  const PAGE_SIZE = 20;

  const load = async (p = 1) => {
    if (!user) return;
    setLoading(true);
    const { startDate, endDate } = getPeriodDates(period, customStart, customEnd);
    const keyId = filterKey === 'all' ? undefined : filterKey;
    const { data, count: total } = await getQuotaRecords(user.id, startDate, endDate, keyId, undefined, p, PAGE_SIZE);
    setRecords(data);
    setCount(total);
    setPage(p);
    setLoading(false);
  };

  useEffect(() => {
    if (!user) { navigate('/login'); return; }
    getApiKeys(user.id).then(setApiKeys);
    load(1);
  }, [user, period, filterKey]);

  const totalAmount = records.reduce((s, r) => s + r.amount, 0);

  return (
    <AppLayout>
      <div className="max-w-5xl mx-auto space-y-5">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div>
            <h1 className="text-xl font-semibold text-foreground">{t('quotaRecords.title')}</h1>
            <p className="text-sm text-muted-foreground mt-0.5">查看额度消耗明细记录</p>
          </div>
          <div className="bg-muted/60 px-3 py-2 rounded-md text-sm">
            <span className="text-muted-foreground">{t('quotaRecords.totalConsumed')}：</span>
            <span className="font-medium text-foreground">{totalAmount.toFixed(2)}</span>
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-col md:flex-row gap-3">
          <div className="flex gap-1">
            {(['today', 'week', 'month', 'custom'] as Period[]).map(p => (
              <button
                key={p}
                onClick={() => { setPeriod(p); }}
                className={`px-3 py-1.5 text-xs rounded-md transition-colors ${
                  period === p
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-muted text-muted-foreground hover:text-foreground'
                }`}
              >
                {t(`quotaRecords.filter.${p}`)}
              </button>
            ))}
          </div>

          {period === 'custom' && (
            <div className="flex gap-2 items-center">
              <Input type="date" value={customStart} onChange={e => setCustomStart(e.target.value)} className="h-8 text-xs w-36" />
              <span className="text-muted-foreground text-xs">至</span>
              <Input type="date" value={customEnd} onChange={e => setCustomEnd(e.target.value)} className="h-8 text-xs w-36" />
              <Button size="sm" onClick={() => load(1)}>
                <Filter size={12} className="mr-1" /> 筛选
              </Button>
            </div>
          )}

          <select
            value={filterKey}
            onChange={e => setFilterKey(e.target.value)}
            className="h-9 px-3 rounded-md border border-border bg-background text-sm text-foreground md:ml-auto"
          >
            <option value="all">全部密钥</option>
            {apiKeys.map(k => <option key={k.id} value={k.id}>{k.name}</option>)}
          </select>
        </div>

        {/* Records Table */}
        <Card className="border-border min-w-0">
          <CardContent className="p-0">
            {loading ? (
              <div className="p-4 space-y-3">
                {Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-10 w-full" />)}
              </div>
            ) : records.length === 0 ? (
              <div className="py-16 text-center">
                <FileText size={28} className="mx-auto mb-3 text-muted-foreground opacity-30" />
                <p className="text-sm text-muted-foreground">{t('quotaRecords.empty')}</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full min-w-max">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="text-left p-4 text-xs text-muted-foreground font-normal whitespace-nowrap">{t('quotaRecords.time')}</th>
                      <th className="text-left p-4 text-xs text-muted-foreground font-normal whitespace-nowrap">{t('quotaRecords.amount')}</th>
                      <th className="text-left p-4 text-xs text-muted-foreground font-normal whitespace-nowrap">{t('quotaRecords.apiKey')}</th>
                      <th className="text-left p-4 text-xs text-muted-foreground font-normal whitespace-nowrap">{t('quotaRecords.model')}</th>
                      <th className="text-left p-4 text-xs text-muted-foreground font-normal whitespace-nowrap">{t('quotaRecords.description')}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {records.map(r => (
                      <tr key={r.id} className="border-b border-border/50 hover:bg-muted/30 transition-colors">
                        <td className="p-4 text-xs text-muted-foreground whitespace-nowrap">
                          {new Date(r.created_at).toLocaleString('zh-CN', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' })}
                        </td>
                        <td className="p-4 text-sm font-medium text-foreground whitespace-nowrap">
                          -{r.amount.toFixed(2)}
                        </td>
                        <td className="p-4 text-xs text-muted-foreground whitespace-nowrap">
                          {(r as { api_keys?: { name: string } | null }).api_keys?.name || '—'}
                        </td>
                        <td className="p-4 text-xs text-foreground whitespace-nowrap">{r.model_name || '—'}</td>
                        <td className="p-4 text-xs text-muted-foreground">{r.description || '—'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Pagination */}
        {count > PAGE_SIZE && (
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>{t('common.totalItems', { n: count })}</span>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => load(page - 1)}>上一页</Button>
              <span className="px-3 py-1.5">第 {page} 页</span>
              <Button variant="outline" size="sm" disabled={page * PAGE_SIZE >= count} onClick={() => load(page + 1)}>下一页</Button>
            </div>
          </div>
        )}
      </div>
    </AppLayout>
  );
}

import React from 'react';
import { useApp } from '@/contexts/AppContext';
import { AppLayout } from '@/components/layouts/AppLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import type { Theme } from '@/contexts/AppContext';
import { LOCALES, type Locale } from '@/i18n';
import { Sun, Moon, Monitor, Languages } from 'lucide-react';

export default function SettingsPage() {
  const { t, locale, setLocale, theme, setTheme } = useApp();

  const themes: { value: Theme; label: string; icon: React.ReactNode }[] = [
    { value: 'light', label: t('settings.light'), icon: <Sun size={15} /> },
    { value: 'dark', label: t('settings.dark'), icon: <Moon size={15} /> },
    { value: 'system', label: t('settings.system'), icon: <Monitor size={15} /> },
  ];

  return (
    <AppLayout>
      <div className="max-w-2xl mx-auto space-y-5">
        <div>
          <h1 className="text-xl font-semibold text-foreground">{t('settings.title')}</h1>
          <p className="text-sm text-muted-foreground mt-0.5">自定义界面显示偏好</p>
        </div>

        {/* Language */}
        <Card className="border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Languages size={14} className="text-primary" />
              {t('settings.language')}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {LOCALES.map(l => (
                <button
                  key={l.value}
                  onClick={() => setLocale(l.value as Locale)}
                  className={`px-4 py-2 rounded-md text-sm border transition-colors ${
                    locale === l.value
                      ? 'border-primary bg-accent text-primary font-medium'
                      : 'border-border text-muted-foreground hover:text-foreground hover:bg-muted'
                  }`}
                >
                  {l.label}
                </button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Theme */}
        <Card className="border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Sun size={14} className="text-primary" />
              {t('settings.theme')}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {themes.map(th => (
                <button
                  key={th.value}
                  onClick={() => setTheme(th.value)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm border transition-colors ${
                    theme === th.value
                      ? 'border-primary bg-accent text-primary font-medium'
                      : 'border-border text-muted-foreground hover:text-foreground hover:bg-muted'
                  }`}
                >
                  {th.icon}
                  {th.label}
                </button>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}

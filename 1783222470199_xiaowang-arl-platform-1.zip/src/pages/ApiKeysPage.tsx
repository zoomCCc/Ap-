import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useApp } from '@/contexts/AppContext';
import { AppLayout } from '@/components/layouts/AppLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter
} from '@/components/ui/dialog';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle
} from '@/components/ui/alert-dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue
} from '@/components/ui/select';
import { toast } from 'sonner';
import { getApiKeys, createApiKey, updateApiKey, deleteApiKey } from '@/services/api';
import type { ApiKey } from '@/types/types';
import { Plus, Copy, Trash2, Pencil, KeyRound, Eye, EyeOff } from 'lucide-react';

const QUOTA_OPTIONS = [
  { label: '无限', value: 'unlimited' },
  { label: '10元', value: '10' },
  { label: '20元', value: '20' },
  { label: '30元', value: '30' },
  { label: '40元', value: '40' },
  { label: '50元', value: '50' },
  { label: '100元', value: '100' },
  { label: '200元', value: '200' },
  { label: '500元', value: '500' },
];

interface KeyFormData {
  name: string;
  group_name: string;
  quota: string;
  note: string;
}

const defaultForm: KeyFormData = { name: '', group_name: '', quota: 'unlimited', note: '' };

export default function ApiKeysPage() {
  const { user } = useAuth();
  const { t } = useApp();
  const navigate = useNavigate();
  const [keys, setKeys] = useState<ApiKey[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingKey, setEditingKey] = useState<ApiKey | null>(null);
  const [form, setForm] = useState<KeyFormData>(defaultForm);
  const [submitting, setSubmitting] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<ApiKey | null>(null);
  const [revealedKeys, setRevealedKeys] = useState<Set<string>>(new Set());
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const loadKeys = async () => {
    if (!user) return;
    const data = await getApiKeys(user.id);
    setKeys(data);
    setLoading(false);
  };

  useEffect(() => {
    if (!user) { navigate('/login'); return; }
    loadKeys();
  }, [user]);

  const openCreate = () => {
    setEditingKey(null);
    setForm(defaultForm);
    setDialogOpen(true);
  };

  const openEdit = (key: ApiKey) => {
    setEditingKey(key);
    const quotaVal = key.quota_limit === null
      ? 'unlimited'
      : String(key.quota_limit / 10000); // stored in units
    setForm({
      name: key.name,
      group_name: key.group_name,
      quota: key.quota_limit === null ? 'unlimited' : String(key.quota_limit),
      note: key.note || '',
    });
    setDialogOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim() || !form.group_name.trim()) {
      toast.error(t('errors.requiredFields'));
      return;
    }
    setSubmitting(true);
    const quotaLimit = form.quota === 'unlimited' ? null : Number(form.quota);
    try {
      if (editingKey) {
        const { error } = await updateApiKey(editingKey.id, {
          name: form.name,
          group_name: form.group_name,
          quota_limit: quotaLimit,
          note: form.note || null,
        });
        if (error) { toast.error(t('common.error')); return; }
        toast.success('密钥已更新');
      } else {
        const { error } = await createApiKey({
          name: form.name,
          group_name: form.group_name,
          quota_limit: quotaLimit,
          note: form.note || null,
        });
        if (error) { toast.error(t('common.error')); return; }
        toast.success('密钥已创建');
      }
      setDialogOpen(false);
      await loadKeys();
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    const { error } = await deleteApiKey(deleteTarget.id);
    if (error) { toast.error(t('common.error')); return; }
    toast.success('密钥已删除');
    setDeleteTarget(null);
    await loadKeys();
  };

  const handleCopy = (key: ApiKey) => {
    navigator.clipboard.writeText(key.key_value).then(() => {
      setCopiedId(key.id);
      toast.success(t('apiKeys.copied'));
      setTimeout(() => setCopiedId(null), 2000);
    });
  };

  const toggleReveal = (id: string) => {
    setRevealedKeys(prev => {
      const s = new Set(prev);
      if (s.has(id)) s.delete(id); else s.add(id);
      return s;
    });
  };

  const maskKey = (key: string) =>
    key.slice(0, 7) + '•'.repeat(16) + key.slice(-4);

  return (
    <AppLayout>
      <div className="max-w-5xl mx-auto space-y-5">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-semibold text-foreground">{t('apiKeys.title')}</h1>
            <p className="text-sm text-muted-foreground mt-0.5">管理您的API访问密钥</p>
          </div>
          <Button size="sm" onClick={openCreate}>
            <Plus size={14} className="mr-1.5" /> {t('apiKeys.create')}
          </Button>
        </div>

        {loading ? (
          <div className="space-y-3">
            {Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-20 rounded-lg" />
            ))}
          </div>
        ) : keys.length === 0 ? (
          <Card className="border-border">
            <CardContent className="py-16 text-center">
              <KeyRound size={32} className="mx-auto mb-3 text-muted-foreground opacity-40" />
              <p className="text-sm text-muted-foreground">{t('apiKeys.empty')}</p>
              <Button size="sm" className="mt-4" onClick={openCreate}>
                <Plus size={13} className="mr-1.5" /> 创建第一个密钥
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-3">
            {keys.map(key => (
              <Card key={key.id} className="border-border">
                <CardContent className="p-4">
                  <div className="flex items-start gap-3 flex-wrap">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-medium text-sm text-foreground">{key.name}</span>
                        <Badge variant="outline" className="text-xs">{key.group_name}</Badge>
                        <Badge variant="outline" className={`text-xs ${key.is_active ? 'border-green-300 text-green-700' : 'border-destructive/40 text-destructive'}`}>
                          {key.is_active ? t('apiKeys.active') : t('apiKeys.inactive')}
                        </Badge>
                      </div>

                      {/* Key value */}
                      <div className="flex items-center gap-1.5 mt-2">
                        <code className="text-xs font-mono bg-muted px-2 py-1 rounded text-muted-foreground flex-1 min-w-0 truncate">
                          {revealedKeys.has(key.id) ? key.key_value : maskKey(key.key_value)}
                        </code>
                        <button onClick={() => toggleReveal(key.id)}
                          className="text-muted-foreground hover:text-foreground shrink-0 p-1">
                          {revealedKeys.has(key.id) ? <EyeOff size={13} /> : <Eye size={13} />}
                        </button>
                        <button onClick={() => handleCopy(key)}
                          className="text-muted-foreground hover:text-foreground shrink-0 p-1">
                          <Copy size={13} />
                        </button>
                        {copiedId === key.id && (
                          <span className="text-xs text-primary">{t('apiKeys.copied')}</span>
                        )}
                      </div>

                      {/* Meta info */}
                      <div className="flex flex-wrap gap-4 mt-2 text-xs text-muted-foreground">
                        <span>
                          额度：{key.quota_limit === null ? '无限' : `${key.quota_used}/${key.quota_limit}`}
                        </span>
                        <span>创建：{new Date(key.created_at).toLocaleDateString('zh-CN')}</span>
                        {key.note && <span>备注：{key.note}</span>}
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <Button variant="outline" size="icon" onClick={() => openEdit(key)}
                        className="h-8 w-8">
                        <Pencil size={13} />
                      </Button>
                      <Button variant="outline" size="icon" onClick={() => setDeleteTarget(key)}
                        className="h-8 w-8 text-destructive hover:text-destructive hover:border-destructive/40">
                        <Trash2 size={13} />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Create/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <DialogHeader>
            <DialogTitle>{editingKey ? t('apiKeys.edit') : t('apiKeys.create')}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-3">
            <div>
              <Label className="text-xs text-muted-foreground mb-1">{t('apiKeys.name')} <span className="text-destructive">*</span></Label>
              <Input
                value={form.name}
                onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                placeholder={t('apiKeys.namePlaceholder')}
                required
              />
            </div>
            <div>
              <Label className="text-xs text-muted-foreground mb-1">{t('apiKeys.group')} <span className="text-destructive">*</span></Label>
              <Input
                value={form.group_name}
                onChange={e => setForm(f => ({ ...f, group_name: e.target.value }))}
                placeholder={t('apiKeys.groupPlaceholder')}
                required
              />
            </div>
            <div>
              <Label className="text-xs text-muted-foreground mb-1">{t('apiKeys.quotaLimit')}</Label>
              <Select value={form.quota} onValueChange={v => setForm(f => ({ ...f, quota: v }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {QUOTA_OPTIONS.map(opt => (
                    <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground mb-1">
                {t('apiKeys.note')} <span className="text-muted-foreground/60">({t('common.optional')})</span>
              </Label>
              <Textarea
                value={form.note}
                onChange={e => setForm(f => ({ ...f, note: e.target.value }))}
                placeholder={t('apiKeys.notePlaceholder')}
                rows={2}
                className="resize-none"
              />
            </div>
            <DialogFooter className="pt-2">
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                {t('common.cancel')}
              </Button>
              <Button type="submit" disabled={submitting}>
                {submitting ? '处理中...' : editingKey ? t('common.save') : t('common.create')}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirm */}
      <AlertDialog open={!!deleteTarget} onOpenChange={open => !open && setDeleteTarget(null)}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <AlertDialogHeader>
            <AlertDialogTitle>确认删除</AlertDialogTitle>
            <AlertDialogDescription>{t('apiKeys.deleteConfirm')}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t('common.cancel')}</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              {t('common.delete')}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </AppLayout>
  );
}

import React, { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useApp } from '@/contexts/AppContext';
import { AppLayout } from '@/components/layouts/AppLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { getApiKeys, getQuotaTrend } from '@/services/api';
import { getFavorites } from '@/services/api';
import type { ApiKey } from '@/types/types';
import {
  AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid
} from 'recharts';
import {
  Cpu, KeyRound, FileText, ScrollText, BarChart2,
  ArrowRight, Megaphone, Zap
} from 'lucide-react';

export default function DashboardPage() {
  const { user, profile } = useAuth();
  const { t } = useApp();
  const navigate = useNavigate();
  const [keys, setKeys] = useState<ApiKey[]>([]);
  const [favorites, setFavorites] = useState<number>(0);
  const [trend, setTrend] = useState<{ date: string; amount: number }[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) { navigate('/login'); return; }
    const load = async () => {
      const [apiKeys, favs, trendData] = await Promise.all([
        getApiKeys(user.id),
        getFavorites(user.id),
        getQuotaTrend(user.id, 7),
      ]);
      setKeys(apiKeys);
      setFavorites(favs.length);
      setTrend(trendData);
      setLoading(false);
    };
    load();
  }, [user, navigate]);

  if (!user) return null;

  const remaining = (profile?.quota_total ?? 0) - (profile?.quota_used ?? 0);
  const usedPercent = profile ? Math.min(100, (profile.quota_used / profile.quota_total) * 100) : 0;

  const stats = [
    {
      label: t('dashboard.remainingQuota'),
      value: loading ? null : remaining.toLocaleString(),
      sub: `总额度 ${(profile?.quota_total ?? 0).toLocaleString()}`,
      color: 'text-primary',
    },
    {
      label: t('dashboard.usedQuota'),
      value: loading ? null : `${usedPercent.toFixed(1)}%`,
      sub: `已用 ${(profile?.quota_used ?? 0).toLocaleString()}`,
      color: 'text-muted-foreground',
    },
    {
      label: t('dashboard.apiKeyCount'),
      value: loading ? null : keys.length.toString(),
      sub: '个活跃密钥',
      color: 'text-foreground',
    },
    {
      label: t('dashboard.favoriteCount'),
      value: loading ? null : favorites.toString(),
      sub: '个收藏模型',
      color: 'text-foreground',
    },
  ];

  const quickActions = [
    { icon: <Cpu size={16} />, label: t('dashboard.browseModels'), path: '/models' },
    { icon: <KeyRound size={16} />, label: t('dashboard.createKey'), path: '/api-keys' },
    { icon: <FileText size={16} />, label: t('dashboard.viewRecords'), path: '/quota-records' },
    { icon: <ScrollText size={16} />, label: 'API日志', path: '/api-logs' },
    { icon: <BarChart2 size={16} />, label: '数据统计', path: '/statistics' },
  ];

  return (
    <AppLayout>
      <div className="max-w-5xl mx-auto space-y-6">
        {/* Welcome */}
        <div className="opacity-0 intersect:opacity-100 translate-y-2 intersect:translate-y-0 transition duration-500">
          <h1 className="text-xl font-semibold text-foreground">
            {t('dashboard.welcome')}，{profile?.display_name || profile?.email?.split('@')[0] || '用户'}
          </h1>
          <p className="text-sm text-muted-foreground mt-0.5">每条消息消耗 0.7 额度</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {stats.map((s, i) => (
            <Card key={i} className="border-border">
              <CardContent className="p-4">
                {loading ? (
                  <Skeleton className="h-7 w-20 mb-1" />
                ) : (
                  <div className={`text-2xl font-semibold ${s.color}`}>{s.value}</div>
                )}
                <div className="text-xs text-muted-foreground mt-0.5">{s.label}</div>
                <div className="text-xs text-muted-foreground/70 mt-0.5">{s.sub}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Trend Chart */}
        <Card className="border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Zap size={14} className="text-primary" />
              {t('dashboard.recentUsage')}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <Skeleton className="h-40 w-full" />
            ) : (
              <ResponsiveContainer width="100%" height={160}>
                <AreaChart data={trend} margin={{ top: 4, right: 8, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="quotaGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.15} />
                      <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="date" tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} />
                  <YAxis tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} />
                  <Tooltip
                    contentStyle={{
                      background: 'hsl(var(--background))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '6px',
                      fontSize: '12px',
                    }}
                  />
                  <Area
                    type="monotone" dataKey="amount" name="消耗额度"
                    stroke="hsl(var(--primary))" fill="url(#quotaGrad)" strokeWidth={1.5}
                  />
                </AreaChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Quick Actions */}
          <Card className="border-border">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">{t('dashboard.quickActions')}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-1">
              {quickActions.map(a => (
                <Link
                  key={a.path}
                  to={a.path}
                  className="flex items-center justify-between px-3 py-2 rounded-md hover:bg-muted transition-colors group"
                >
                  <div className="flex items-center gap-2.5 text-sm text-foreground">
                    <span className="text-muted-foreground">{a.icon}</span>
                    {a.label}
                  </div>
                  <ArrowRight size={13} className="text-muted-foreground group-hover:text-foreground transition-colors" />
                </Link>
              ))}
            </CardContent>
          </Card>

          {/* Announcements */}
          <Card className="border-border">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Megaphone size={14} className="text-primary" />
                {t('dashboard.announcements')}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {[
                { date: '2026-07-05', text: '平台正式上线！注册即送1000万额度，邀请好友共同使用。' },
                { date: '2026-07-05', text: '模型中心已收录30+主流AI大模型，持续更新中。' },
                { date: '2026-07-05', text: '支持邮箱和手机号注册/登录，验证码实时送达。' },
              ].map((a, i) => (
                <div key={i} className="border-l-2 border-primary/30 pl-3">
                  <p className="text-xs text-foreground leading-relaxed">{a.text}</p>
                  <p className="text-xs text-muted-foreground mt-1">{a.date}</p>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
}

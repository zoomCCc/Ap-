import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useApp } from '@/contexts/AppContext';
import { AppLayout } from '@/components/layouts/AppLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import { User, Mail, Phone, Lock, Eye, EyeOff, Loader2, ShieldCheck } from 'lucide-react';

export default function ProfilePage() {
  const { user, profile, refreshProfile } = useAuth();
  const { t } = useApp();
  const navigate = useNavigate();

  const [pwdSection, setPwdSection] = useState(false);
  const [emailSection, setEmailSection] = useState(false);
  const [phoneSection, setPhoneSection] = useState(false);

  const [oldPwd, setOldPwd] = useState('');
  const [newPwd, setNewPwd] = useState('');
  const [confirmPwd, setConfirmPwd] = useState('');
  const [showPwd, setShowPwd] = useState(false);
  const [pwdLoading, setPwdLoading] = useState(false);

  const [newEmail, setNewEmail] = useState('');
  const [emailCode, setEmailCode] = useState('');
  const [emailCodeSent, setEmailCodeSent] = useState(false);
  const [emailCountdown, setEmailCountdown] = useState(0);
  const [emailLoading, setEmailLoading] = useState(false);

  const [newPhone, setNewPhone] = useState('');
  const [phoneCode, setPhoneCode] = useState('');
  const [phoneCodeSent, setPhoneCodeSent] = useState(false);
  const [phoneCountdown, setPhoneCountdown] = useState(0);
  const [phoneLoading, setPhoneLoading] = useState(false);

  if (!user) { navigate('/login'); return null; }

  const startCountdown = (setter: React.Dispatch<React.SetStateAction<number>>) => {
    setter(60);
    const timer = setInterval(() => {
      setter(prev => { if (prev <= 1) { clearInterval(timer); return 0; } return prev - 1; });
    }, 1000);
  };

  const handleChangePwd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPwd !== confirmPwd) { toast.error(t('errors.passwordMismatch')); return; }
    if (newPwd.length < 8) { toast.error('密码至少8位'); return; }
    setPwdLoading(true);
    try {
      // Verify old password first
      const { error: signInErr } = await supabase.auth.signInWithPassword({
        email: user.email || '',
        password: oldPwd,
      });
      if (signInErr) { toast.error(t('errors.oldPasswordWrong')); return; }
      const { error } = await supabase.auth.updateUser({ password: newPwd });
      if (error) { toast.error(t('common.error')); return; }
      toast.success('密码修改成功');
      setPwdSection(false);
      setOldPwd(''); setNewPwd(''); setConfirmPwd('');
    } finally {
      setPwdLoading(false);
    }
  };

  const handleSendEmailCode = async () => {
    if (!newEmail) return;
    const { error } = await supabase.auth.signInWithOtp({ email: newEmail });
    if (error) { toast.error(t('errors.codeSendFail')); return; }
    setEmailCodeSent(true);
    startCountdown(setEmailCountdown);
    toast.success('验证码已发送至新邮箱');
  };

  const handleChangeEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    setEmailLoading(true);
    try {
      const { error } = await supabase.auth.verifyOtp({ email: newEmail, token: emailCode, type: 'email' });
      if (error) { toast.error(t('errors.codeWrong')); return; }
      const { error: e2 } = await supabase.auth.updateUser({ email: newEmail });
      if (e2) { toast.error(t('common.error')); return; }
      toast.success('邮箱修改成功');
      setEmailSection(false);
      await refreshProfile();
    } finally {
      setEmailLoading(false);
    }
  };

  const handleSendPhoneCode = async () => {
    if (!newPhone) return;
    const formatted = newPhone.startsWith('+') ? newPhone : `+86${newPhone}`;
    const { error } = await supabase.auth.signInWithOtp({ phone: formatted });
    if (error) { toast.error(t('errors.codeSendFail')); return; }
    setPhoneCodeSent(true);
    startCountdown(setPhoneCountdown);
    toast.success('验证码已发送');
  };

  const handleChangePhone = async (e: React.FormEvent) => {
    e.preventDefault();
    setPhoneLoading(true);
    try {
      const formatted = newPhone.startsWith('+') ? newPhone : `+86${newPhone}`;
      const { error } = await supabase.auth.verifyOtp({ phone: formatted, token: phoneCode, type: 'sms' });
      if (error) { toast.error(t('errors.codeWrong')); return; }
      const { error: e2 } = await supabase.auth.updateUser({ phone: formatted });
      if (e2) { toast.error(t('common.error')); return; }
      toast.success('手机号修改成功');
      setPhoneSection(false);
      await refreshProfile();
    } finally {
      setPhoneLoading(false);
    }
  };

  const roleLabel = { user: t('profile.roles.user'), vip: t('profile.roles.vip'), admin: t('profile.roles.admin') };

  return (
    <AppLayout>
      <div className="max-w-2xl mx-auto space-y-5">
        <div>
          <h1 className="text-xl font-semibold text-foreground">{t('profile.title')}</h1>
          <p className="text-sm text-muted-foreground mt-0.5">管理您的账户信息</p>
        </div>

        {/* Basic Info */}
        <Card className="border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <User size={14} className="text-primary" /> 账户信息
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-xs text-muted-foreground">{t('profile.email')}</span>
                <p className="text-foreground mt-0.5">{profile?.email || user.email || '—'}</p>
              </div>
              <div>
                <span className="text-xs text-muted-foreground">{t('profile.phone')}</span>
                <p className="text-foreground mt-0.5">{profile?.phone || user.phone || '—'}</p>
              </div>
              <div>
                <span className="text-xs text-muted-foreground">{t('profile.role')}</span>
                <div className="mt-0.5">
                  <Badge variant="outline" className="text-xs">
                    <ShieldCheck size={11} className="mr-1" />
                    {roleLabel[profile?.role || 'user']}
                  </Badge>
                </div>
              </div>
              <div>
                <span className="text-xs text-muted-foreground">{t('profile.registeredAt')}</span>
                <p className="text-foreground mt-0.5">
                  {profile?.created_at ? new Date(profile.created_at).toLocaleDateString('zh-CN') : '—'}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Change Password */}
        <Card className="border-border">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Lock size={14} className="text-primary" /> {t('profile.changePassword')}
              </CardTitle>
              <Button variant="ghost" size="sm" onClick={() => setPwdSection(!pwdSection)}>
                {pwdSection ? '收起' : '修改'}
              </Button>
            </div>
          </CardHeader>
          {pwdSection && (
            <CardContent>
              <form onSubmit={handleChangePwd} className="space-y-3">
                <div>
                  <Label className="text-xs text-muted-foreground mb-1">{t('profile.oldPassword')}</Label>
                  <div className="relative">
                    <Input type={showPwd ? 'text' : 'password'} value={oldPwd}
                      onChange={e => setOldPwd(e.target.value)} placeholder="请输入当前密码" required className="pr-10" />
                    <button type="button" onClick={() => setShowPwd(!showPwd)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                      {showPwd ? <EyeOff size={13} /> : <Eye size={13} />}
                    </button>
                  </div>
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground mb-1">{t('profile.newPassword')}</Label>
                  <Input type="password" value={newPwd} onChange={e => setNewPwd(e.target.value)}
                    placeholder="请输入新密码（至少8位）" required />
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground mb-1">{t('profile.confirmNewPassword')}</Label>
                  <Input type="password" value={confirmPwd} onChange={e => setConfirmPwd(e.target.value)}
                    placeholder="请再次输入新密码" required />
                </div>
                <Button type="submit" size="sm" disabled={pwdLoading}>
                  {pwdLoading ? <Loader2 size={13} className="animate-spin mr-1.5" /> : null}
                  {t('common.save')}
                </Button>
              </form>
            </CardContent>
          )}
        </Card>

        {/* Change Email */}
        <Card className="border-border">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Mail size={14} className="text-primary" /> {t('profile.changeEmail')}
              </CardTitle>
              <Button variant="ghost" size="sm" onClick={() => setEmailSection(!emailSection)}>
                {emailSection ? '收起' : '修改'}
              </Button>
            </div>
          </CardHeader>
          {emailSection && (
            <CardContent>
              <form onSubmit={handleChangeEmail} className="space-y-3">
                <div>
                  <Label className="text-xs text-muted-foreground mb-1">{t('profile.newEmail')}</Label>
                  <Input type="email" value={newEmail} onChange={e => setNewEmail(e.target.value)}
                    placeholder="请输入新邮箱地址" required />
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground mb-1">{t('auth.verifyCode')}</Label>
                  <div className="flex gap-2">
                    <Input value={emailCode} onChange={e => setEmailCode(e.target.value)}
                      placeholder={t('auth.codePlaceholder')} required className="flex-1" />
                    <Button type="button" variant="outline" onClick={handleSendEmailCode}
                      disabled={emailCountdown > 0} className="shrink-0 text-xs px-3">
                      {emailCountdown > 0 ? `${emailCountdown}s` : t('auth.sendCode')}
                    </Button>
                  </div>
                </div>
                <Button type="submit" size="sm" disabled={emailLoading || !emailCodeSent}>
                  {emailLoading ? <Loader2 size={13} className="animate-spin mr-1.5" /> : null}
                  {t('common.save')}
                </Button>
              </form>
            </CardContent>
          )}
        </Card>

        {/* Change Phone */}
        <Card className="border-border">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Phone size={14} className="text-primary" /> {t('profile.changePhone')}
              </CardTitle>
              <Button variant="ghost" size="sm" onClick={() => setPhoneSection(!phoneSection)}>
                {phoneSection ? '收起' : '修改'}
              </Button>
            </div>
          </CardHeader>
          {phoneSection && (
            <CardContent>
              <form onSubmit={handleChangePhone} className="space-y-3">
                <div>
                  <Label className="text-xs text-muted-foreground mb-1">{t('profile.newPhone')}</Label>
                  <Input type="tel" value={newPhone} onChange={e => setNewPhone(e.target.value)}
                    placeholder="请输入新手机号" required />
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground mb-1">{t('auth.verifyCode')}</Label>
                  <div className="flex gap-2">
                    <Input value={phoneCode} onChange={e => setPhoneCode(e.target.value)}
                      placeholder={t('auth.codePlaceholder')} required className="flex-1" />
                    <Button type="button" variant="outline" onClick={handleSendPhoneCode}
                      disabled={phoneCountdown > 0} className="shrink-0 text-xs px-3">
                      {phoneCountdown > 0 ? `${phoneCountdown}s` : t('auth.sendCode')}
                    </Button>
                  </div>
                </div>
                <Button type="submit" size="sm" disabled={phoneLoading || !phoneCodeSent}>
                  {phoneLoading ? <Loader2 size={13} className="animate-spin mr-1.5" /> : null}
                  {t('common.save')}
                </Button>
              </form>
            </CardContent>
          )}
        </Card>
      </div>
    </AppLayout>
  );
}

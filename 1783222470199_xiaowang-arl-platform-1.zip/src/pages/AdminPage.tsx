import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useApp } from '@/contexts/AppContext';
import { AppLayout } from '@/components/layouts/AppLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter
} from '@/components/ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import {
  getAllProfiles, updateUserRole, adjustUserQuota, toggleUserActive
} from '@/services/api';
import type { Profile, UserRole } from '@/types/types';
import { Users, ShieldCheck, UserX, UserCheck, Coins } from 'lucide-react';

export default function AdminPage() {
  const { user, profile } = useAuth();
  const { t } = useApp();
  const navigate = useNavigate();
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [count, setCount] = useState(0);
  const [page, setPage] = useState(1);
  const [roleDialog, setRoleDialog] = useState<Profile | null>(null);
  const [quotaDialog, setQuotaDialog] = useState<Profile | null>(null);
  const [selectedRole, setSelectedRole] = useState<UserRole>('user');
  const [quotaDelta, setQuotaDelta] = useState('');
  const [saving, setSaving] = useState(false);
  const PAGE_SIZE = 20;

  const load = async (p = 1) => {
    setLoading(true);
    const { data, count: total } = await getAllProfiles(p, PAGE_SIZE);
    setProfiles(data);
    setCount(total);
    setPage(p);
    setLoading(false);
  };

  useEffect(() => {
    if (!user) { navigate('/login'); return; }
    if (profile && profile.role !== 'admin') {
      toast.error(t('errors.unauthorized'));
      navigate('/dashboard');
      return;
    }
    load(1);
  }, [user, profile]);

  const handleSetRole = async () => {
    if (!roleDialog) return;
    setSaving(true);
    const { error } = await updateUserRole(roleDialog.id, selectedRole);
    if (error) { toast.error(t('common.error')); } else {
      toast.success('权限已更新');
      setRoleDialog(null);
      await load(page);
    }
    setSaving(false);
  };

  const handleAdjustQuota = async () => {
    if (!quotaDialog) return;
    const delta = Number(quotaDelta);
    if (isNaN(delta)) { toast.error('请输入有效数字'); return; }
    setSaving(true);
    const { error } = await adjustUserQuota(quotaDialog.id, delta);
    if (error) { toast.error(t('common.error')); } else {
      toast.success('额度已调整');
      setQuotaDialog(null);
      setQuotaDelta('');
      await load(page);
    }
    setSaving(false);
  };

  const handleToggleActive = async (p: Profile) => {
    const { error } = await toggleUserActive(p.id, !p.is_active);
    if (error) { toast.error(t('common.error')); } else {
      toast.success(p.is_active ? '已禁用' : '已启用');
      await load(page);
    }
  };

  const roleColors: Record<UserRole, string> = {
    user: 'bg-secondary text-secondary-foreground',
    vip: 'bg-amber-100 text-amber-700 border border-amber-300',
    admin: 'bg-primary/10 text-primary border border-primary/30',
  };

  return (
    <AppLayout>
      <div className="max-w-5xl mx-auto space-y-5">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-semibold text-foreground">{t('admin.title')}</h1>
            <p className="text-sm text-muted-foreground mt-0.5">管理所有用户账户与权限</p>
          </div>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Users size={14} />
            共 {count} 位用户
          </div>
        </div>

        <Card className="border-border min-w-0">
          <CardContent className="p-0">
            {loading ? (
              <div className="p-4 space-y-3">
                {Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-10 w-full" />)}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full min-w-max">
                  <thead>
                    <tr className="border-b border-border">
                      {[t('admin.email'), t('admin.phone'), t('admin.role'), t('admin.quota'),
                        t('admin.createdAt'), t('admin.status'), t('admin.actions')].map(h => (
                        <th key={h} className="text-left p-4 text-xs text-muted-foreground font-normal whitespace-nowrap">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {profiles.map(p => (
                      <tr key={p.id} className="border-b border-border/50 hover:bg-muted/30 transition-colors">
                        <td className="p-4 text-xs text-foreground whitespace-nowrap">{p.email || '—'}</td>
                        <td className="p-4 text-xs text-foreground whitespace-nowrap">{p.phone || '—'}</td>
                        <td className="p-4 whitespace-nowrap">
                          <span className={`text-xs px-2 py-0.5 rounded-full ${roleColors[p.role]}`}>
                            {t(`profile.roles.${p.role}`)}
                          </span>
                        </td>
                        <td className="p-4 text-xs text-foreground whitespace-nowrap">
                          {((p.quota_total - p.quota_used)).toLocaleString()}
                        </td>
                        <td className="p-4 text-xs text-muted-foreground whitespace-nowrap">
                          {new Date(p.created_at).toLocaleDateString('zh-CN')}
                        </td>
                        <td className="p-4 whitespace-nowrap">
                          <Badge variant="outline" className={`text-xs ${p.is_active ? 'border-green-300 text-green-700' : 'border-destructive/40 text-destructive'}`}>
                            {p.is_active ? t('admin.active') : t('admin.inactive')}
                          </Badge>
                        </td>
                        <td className="p-4 whitespace-nowrap">
                          <div className="flex items-center gap-1">
                            <Button size="icon" variant="ghost" className="h-7 w-7"
                              onClick={() => { setRoleDialog(p); setSelectedRole(p.role); }}
                              title={t('admin.setRole')}>
                              <ShieldCheck size={12} />
                            </Button>
                            <Button size="icon" variant="ghost" className="h-7 w-7"
                              onClick={() => { setQuotaDialog(p); setQuotaDelta(''); }}
                              title={t('admin.adjustQuota')}>
                              <Coins size={12} />
                            </Button>
                            <Button size="icon" variant="ghost" className="h-7 w-7"
                              onClick={() => handleToggleActive(p)}
                              title={t('admin.toggleStatus')}>
                              {p.is_active ? <UserX size={12} /> : <UserCheck size={12} />}
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>

        {count > PAGE_SIZE && (
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>{t('common.totalItems', { n: count })}</span>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => load(page - 1)}>上一页</Button>
              <span className="px-3 py-1.5">第 {page} 页</span>
              <Button variant="outline" size="sm" disabled={page * PAGE_SIZE >= count} onClick={() => load(page + 1)}>下一页</Button>
            </div>
          </div>
        )}
      </div>

      {/* Role Dialog */}
      <Dialog open={!!roleDialog} onOpenChange={open => !open && setRoleDialog(null)}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-sm">
          <DialogHeader>
            <DialogTitle>{t('admin.setRole')}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <p className="text-xs text-muted-foreground">{roleDialog?.email || roleDialog?.phone}</p>
            <Select value={selectedRole} onValueChange={v => setSelectedRole(v as UserRole)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="user">{t('profile.roles.user')}</SelectItem>
                <SelectItem value="vip">{t('profile.roles.vip')}</SelectItem>
                <SelectItem value="admin">{t('profile.roles.admin')}</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setRoleDialog(null)}>{t('common.cancel')}</Button>
            <Button onClick={handleSetRole} disabled={saving}>{t('common.save')}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Quota Dialog */}
      <Dialog open={!!quotaDialog} onOpenChange={open => !open && setQuotaDialog(null)}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-sm">
          <DialogHeader>
            <DialogTitle>{t('admin.adjustQuota')}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <p className="text-xs text-muted-foreground">{quotaDialog?.email || quotaDialog?.phone}</p>
            <p className="text-xs text-muted-foreground">
              当前余额：{quotaDialog ? (quotaDialog.quota_total - quotaDialog.quota_used).toLocaleString() : '—'}
            </p>
            <div>
              <Label className="text-xs text-muted-foreground mb-1">
                {t('admin.quotaAmount')} <span className="text-muted-foreground/60">（正数增加，负数减少）</span>
              </Label>
              <Input
                type="number"
                value={quotaDelta}
                onChange={e => setQuotaDelta(e.target.value)}
                placeholder="输入调整量，如 1000000"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setQuotaDialog(null)}>{t('common.cancel')}</Button>
            <Button onClick={handleAdjustQuota} disabled={saving}>{t('common.confirm')}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AppLayout>
  );
}

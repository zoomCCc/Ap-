import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useApp } from '@/contexts/AppContext';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuSeparator, DropdownMenuTrigger
} from '@/components/ui/dropdown-menu';
import {
  LayoutDashboard, Cpu, KeyRound, FileText, ScrollText,
  BarChart2, User, Users, Settings, Menu, LogOut, Sun, Moon, Monitor,
  ChevronDown
} from 'lucide-react';
import { toast } from 'sonner';
import type { Theme } from '@/contexts/AppContext';

interface NavItem {
  key: string;
  path: string;
  icon: React.ReactNode;
  adminOnly?: boolean;
}

const navItems: NavItem[] = [
  { key: 'nav.home', path: '/dashboard', icon: <LayoutDashboard size={16} /> },
  { key: 'nav.models', path: '/models', icon: <Cpu size={16} /> },
  { key: 'nav.apiKeys', path: '/api-keys', icon: <KeyRound size={16} /> },
  { key: 'nav.quotaRecords', path: '/quota-records', icon: <FileText size={16} /> },
  { key: 'nav.apiLogs', path: '/api-logs', icon: <ScrollText size={16} /> },
  { key: 'nav.statistics', path: '/statistics', icon: <BarChart2 size={16} /> },
  { key: 'nav.profile', path: '/profile', icon: <User size={16} /> },
  { key: 'nav.admin', path: '/admin', icon: <Users size={16} />, adminOnly: true },
];

const themeIcons: Record<Theme, React.ReactNode> = {
  light: <Sun size={15} />,
  dark: <Moon size={15} />,
  system: <Monitor size={15} />,
};

export const AppLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, profile, signOut } = useAuth();
  const { t, theme, setTheme } = useApp();
  const location = useLocation();
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleLogout = async () => {
    await signOut();
    toast.success('已退出登录');
    navigate('/login');
  };

  const isAdmin = profile?.role === 'admin';
  const visibleNav = navItems.filter(n => !n.adminOnly || isAdmin);

  const SidebarContent = () => (
    <nav className="flex flex-col gap-1 p-3">
      {visibleNav.map(item => {
        const active = location.pathname.startsWith(item.path);
        return (
          <Link
            key={item.path}
            to={item.path}
            onClick={() => setMobileOpen(false)}
            className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm transition-colors ${
              active
                ? 'bg-primary text-primary-foreground font-medium'
                : 'text-muted-foreground hover:text-foreground hover:bg-muted'
            }`}
          >
            {item.icon}
            {t(item.key)}
          </Link>
        );
      })}
    </nav>
  );

  return (
    <div className="flex min-h-screen w-full bg-muted/30">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex flex-col w-56 shrink-0 border-r border-border bg-sidebar min-h-screen">
        <div className="px-4 py-5 border-b border-sidebar-border">
          <h1 className="text-base font-semibold text-foreground leading-tight">{t('appName')}</h1>
          <p className="text-xs text-muted-foreground mt-0.5">{t('appSubtitle')}</p>
        </div>
        <div className="flex-1 overflow-y-auto">
          <SidebarContent />
        </div>
        <div className="px-3 py-3 border-t border-sidebar-border">
          <Link
            to="/settings"
            className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm transition-colors ${
              location.pathname === '/settings'
                ? 'bg-primary text-primary-foreground font-medium'
                : 'text-muted-foreground hover:text-foreground hover:bg-muted'
            }`}
          >
            <Settings size={16} />
            {t('nav.settings')}
          </Link>
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 min-w-0 flex flex-col">
        {/* Header */}
        <header className="h-14 border-b border-border bg-background flex items-center px-4 gap-3 shrink-0">
          {/* Mobile menu */}
          <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="lg:hidden shrink-0">
                <Menu size={18} />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-56 p-0 bg-sidebar">
              <div className="px-4 py-5 border-b border-sidebar-border">
                <h1 className="text-base font-semibold">{t('appName')}</h1>
                <p className="text-xs text-muted-foreground mt-0.5">{t('appSubtitle')}</p>
              </div>
              <SidebarContent />
              <div className="px-3 py-3 border-t border-sidebar-border">
                <Link
                  to="/settings"
                  onClick={() => setMobileOpen(false)}
                  className="flex items-center gap-3 px-3 py-2 rounded-md text-sm text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
                >
                  <Settings size={16} />
                  {t('nav.settings')}
                </Link>
              </div>
            </SheetContent>
          </Sheet>

          <div className="flex-1 min-w-0 lg:hidden">
            <span className="text-sm font-medium text-foreground truncate">{t('appFullName')}</span>
          </div>

          <div className="ml-auto flex items-center gap-2">
            {/* Theme Toggle */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="text-muted-foreground">
                  {themeIcons[theme]}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => setTheme('light')}>
                  <Sun size={14} className="mr-2" /> {t('settings.light')}
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setTheme('dark')}>
                  <Moon size={14} className="mr-2" /> {t('settings.dark')}
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setTheme('system')}>
                  <Monitor size={14} className="mr-2" /> {t('settings.system')}
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            {/* User menu */}
            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="flex items-center gap-1.5 text-sm px-3">
                    <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                      <User size={13} className="text-primary" />
                    </div>
                    <span className="hidden md:block max-w-28 truncate text-foreground">
                      {profile?.display_name || profile?.email || profile?.phone || '用户'}
                    </span>
                    <ChevronDown size={13} className="text-muted-foreground" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-44">
                  <DropdownMenuItem onClick={() => navigate('/profile')}>
                    <User size={14} className="mr-2" /> {t('nav.profile')}
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout} className="text-destructive">
                    <LogOut size={14} className="mr-2" /> {t('auth.logout')}
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Button size="sm" onClick={() => navigate('/login')}>{t('auth.login')}</Button>
            )}
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-y-auto p-4 md:p-6">
          {children}
        </main>
      </div>
    </div>
  );
};

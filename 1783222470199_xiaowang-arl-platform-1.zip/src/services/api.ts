import { supabase } from '@/db/supabase';
import type { Profile, ApiKey, Model, ModelFavorite, QuotaRecord, ApiLog, UserRole } from '@/types/types';

// ─── Profile ──────────────────────────────────────────────

export async function getProfile(userId: string): Promise<Profile | null> {
  const { data } = await supabase.from('profiles').select('*').eq('id', userId).maybeSingle();
  return data as Profile | null;
}

export async function updateProfile(userId: string, updates: Partial<Profile>): Promise<{ error: string | null }> {
  const { error } = await supabase.from('profiles').update(updates).eq('id', userId);
  return { error: error?.message ?? null };
}

export async function getAllProfiles(page = 1, pageSize = 20): Promise<{ data: Profile[]; count: number }> {
  const from = (page - 1) * pageSize;
  const to = from + pageSize - 1;
  const { data, count, error } = await supabase
    .from('profiles')
    .select('*', { count: 'exact' })
    .order('created_at', { ascending: false })
    .range(from, to);
  if (error) return { data: [], count: 0 };
  return { data: (data ?? []) as Profile[], count: count ?? 0 };
}

export async function updateUserRole(userId: string, role: UserRole): Promise<{ error: string | null }> {
  const { error } = await supabase.from('profiles').update({ role }).eq('id', userId);
  return { error: error?.message ?? null };
}

export async function adjustUserQuota(userId: string, delta: number): Promise<{ error: string | null }> {
  const profile = await getProfile(userId);
  if (!profile) return { error: '用户不存在' };
  const { error } = await supabase
    .from('profiles')
    .update({ quota_total: Math.max(0, profile.quota_total + delta) })
    .eq('id', userId);
  return { error: error?.message ?? null };
}

export async function toggleUserActive(userId: string, isActive: boolean): Promise<{ error: string | null }> {
  const { error } = await supabase.from('profiles').update({ is_active: isActive }).eq('id', userId);
  return { error: error?.message ?? null };
}

// ─── Models ───────────────────────────────────────────────

export async function getModels(): Promise<Model[]> {
  const { data } = await supabase
    .from('models')
    .select('*')
    .eq('is_active', true)
    .order('sort_order', { ascending: true });
  return (data ?? []) as Model[];
}

export async function getModelById(id: string): Promise<Model | null> {
  const { data } = await supabase.from('models').select('*').eq('id', id).maybeSingle();
  return data as Model | null;
}

// ─── Model Favorites ──────────────────────────────────────

export async function getFavorites(userId: string): Promise<ModelFavorite[]> {
  const { data } = await supabase
    .from('model_favorites')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
  return (data ?? []) as ModelFavorite[];
}

export async function addFavorite(userId: string, modelId: string): Promise<{ error: string | null }> {
  const { error } = await supabase.from('model_favorites').insert({ user_id: userId, model_id: modelId });
  return { error: error?.message ?? null };
}

export async function removeFavorite(userId: string, modelId: string): Promise<{ error: string | null }> {
  const { error } = await supabase
    .from('model_favorites')
    .delete()
    .eq('user_id', userId)
    .eq('model_id', modelId);
  return { error: error?.message ?? null };
}

// ─── API Keys ─────────────────────────────────────────────

export async function getApiKeys(userId: string): Promise<ApiKey[]> {
  const { data } = await supabase
    .from('api_keys')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
  return (data ?? []) as ApiKey[];
}

export interface CreateApiKeyInput {
  name: string;
  group_name: string;
  quota_limit: number | null;
  note: string | null;
}

export async function createApiKey(input: CreateApiKeyInput): Promise<{ error: string | null }> {
  const { error } = await supabase.from('api_keys').insert(input);
  return { error: error?.message ?? null };
}

export async function updateApiKey(id: string, input: Partial<CreateApiKeyInput>): Promise<{ error: string | null }> {
  const { error } = await supabase.from('api_keys').update(input).eq('id', id);
  return { error: error?.message ?? null };
}

export async function deleteApiKey(id: string): Promise<{ error: string | null }> {
  const { error } = await supabase.from('api_keys').delete().eq('id', id);
  return { error: error?.message ?? null };
}

// ─── Quota Records ────────────────────────────────────────

export async function getQuotaRecords(
  userId: string,
  startDate?: string,
  endDate?: string,
  apiKeyId?: string,
  modelId?: string,
  page = 1,
  pageSize = 20
): Promise<{ data: QuotaRecord[]; count: number }> {
  const from = (page - 1) * pageSize;
  const to = from + pageSize - 1;
  let query = supabase
    .from('quota_records')
    .select('*, api_keys!api_key_id(name)', { count: 'exact' })
    .eq('user_id', userId)
    .order('created_at', { ascending: false })
    .range(from, to);
  if (startDate) query = query.gte('created_at', startDate);
  if (endDate) query = query.lte('created_at', endDate);
  if (apiKeyId) query = query.eq('api_key_id', apiKeyId);
  if (modelId) query = query.eq('model_id', modelId);
  const { data, count, error } = await query;
  if (error) return { data: [], count: 0 };
  return { data: (data ?? []) as QuotaRecord[], count: count ?? 0 };
}

export async function getTotalQuotaUsed(userId: string): Promise<number> {
  const { data } = await supabase.from('quota_records').select('amount').eq('user_id', userId);
  return (data ?? []).reduce((sum, r) => sum + (r.amount || 0), 0);
}

export async function getQuotaTrend(userId: string, days = 7): Promise<{ date: string; amount: number }[]> {
  const startDate = new Date();
  startDate.setDate(startDate.getDate() - days + 1);
  startDate.setHours(0, 0, 0, 0);
  const { data } = await supabase
    .from('quota_records')
    .select('amount, created_at')
    .eq('user_id', userId)
    .gte('created_at', startDate.toISOString())
    .order('created_at', { ascending: true });

  const map: Record<string, number> = {};
  for (let i = 0; i < days; i++) {
    const d = new Date(startDate);
    d.setDate(d.getDate() + i);
    map[d.toLocaleDateString('zh-CN', { month: '2-digit', day: '2-digit' })] = 0;
  }
  (data ?? []).forEach(r => {
    const d = new Date(r.created_at).toLocaleDateString('zh-CN', { month: '2-digit', day: '2-digit' });
    map[d] = (map[d] || 0) + r.amount;
  });
  return Object.entries(map).map(([date, amount]) => ({ date, amount }));
}

// ─── API Logs ─────────────────────────────────────────────

export async function getApiLogs(
  userId: string,
  startDate?: string,
  endDate?: string,
  apiKeyId?: string,
  modelId?: string,
  status?: string,
  page = 1,
  pageSize = 20
): Promise<{ data: ApiLog[]; count: number }> {
  const from = (page - 1) * pageSize;
  const to = from + pageSize - 1;
  let query = supabase
    .from('api_logs')
    .select('*', { count: 'exact' })
    .eq('user_id', userId)
    .order('created_at', { ascending: false })
    .range(from, to);
  if (startDate) query = query.gte('created_at', startDate);
  if (endDate) query = query.lte('created_at', endDate);
  if (apiKeyId) query = query.eq('api_key_id', apiKeyId);
  if (modelId) query = query.eq('model_id', modelId);
  if (status) query = query.eq('response_status', status);
  const { data, count, error } = await query;
  if (error) return { data: [], count: 0 };
  return { data: (data ?? []) as ApiLog[], count: count ?? 0 };
}

export async function getCallTrend(userId: string, days = 7): Promise<{ date: string; count: number }[]> {
  const startDate = new Date();
  startDate.setDate(startDate.getDate() - days + 1);
  startDate.setHours(0, 0, 0, 0);
  const { data } = await supabase
    .from('api_logs')
    .select('created_at')
    .eq('user_id', userId)
    .gte('created_at', startDate.toISOString())
    .order('created_at', { ascending: true });

  const map: Record<string, number> = {};
  for (let i = 0; i < days; i++) {
    const d = new Date(startDate);
    d.setDate(d.getDate() + i);
    map[d.toLocaleDateString('zh-CN', { month: '2-digit', day: '2-digit' })] = 0;
  }
  (data ?? []).forEach(r => {
    const d = new Date(r.created_at).toLocaleDateString('zh-CN', { month: '2-digit', day: '2-digit' });
    map[d] = (map[d] || 0) + 1;
  });
  return Object.entries(map).map(([date, count]) => ({ date, count }));
}

export async function getModelDistribution(userId: string): Promise<{ name: string; value: number }[]> {
  const { data } = await supabase
    .from('api_logs')
    .select('model_name, quota_used')
    .eq('user_id', userId)
    .not('model_name', 'is', null);
  const map: Record<string, number> = {};
  (data ?? []).forEach(r => {
    if (r.model_name) map[r.model_name] = (map[r.model_name] || 0) + 1;
  });
  return Object.entries(map)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 8)
    .map(([name, value]) => ({ name, value }));
}

export async function getKeyDistribution(userId: string): Promise<{ name: string; value: number }[]> {
  const { data } = await supabase
    .from('quota_records')
    .select('amount, api_keys!api_key_id(name)')
    .eq('user_id', userId);
  const map: Record<string, number> = {};
  (data ?? []).forEach(r => {
    const row = r as unknown as { api_keys?: { name: string } | null; amount: number };
    const name = row.api_keys?.name ?? '未知密钥';
    map[name] = (map[name] || 0) + row.amount;
  });
  return Object.entries(map)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 6)
    .map(([name, value]) => ({ name, value: parseFloat(value.toFixed(2)) }));
}

export type UserRole = 'user' | 'vip' | 'admin';

export interface Profile {
  id: string;
  email: string | null;
  phone: string | null;
  display_name: string | null;
  role: UserRole;
  quota_total: number;
  quota_used: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface Model {
  id: string;
  name: string;
  provider: string;
  category: string;
  description: string | null;
  tags: string[];
  is_active: boolean;
  sort_order: number;
  created_at: string;
  is_favorited?: boolean;
}

export interface ModelFavorite {
  id: string;
  user_id: string;
  model_id: string;
  created_at: string;
}

export interface ApiKey {
  id: string;
  user_id: string;
  name: string;
  group_name: string;
  key_value: string;
  quota_limit: number | null;
  quota_used: number;
  note: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface QuotaRecord {
  id: string;
  user_id: string;
  api_key_id: string | null;
  model_id: string | null;
  model_name: string | null;
  amount: number;
  description: string | null;
  created_at: string;
  api_keys?: { name: string } | null;
}

export interface ApiLog {
  id: string;
  user_id: string;
  api_key_id: string | null;
  api_key_name: string | null;
  model_id: string | null;
  model_name: string | null;
  request_summary: string | null;
  response_status: string;
  quota_used: number;
  created_at: string;
}

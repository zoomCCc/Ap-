
-- Enable extensions
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- User roles enum
CREATE TYPE public.user_role AS ENUM ('user', 'vip', 'admin');

-- Profiles table
CREATE TABLE public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text,
  phone text,
  display_name text,
  role public.user_role NOT NULL DEFAULT 'user',
  quota_total bigint NOT NULL DEFAULT 10000000,
  quota_used bigint NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Helper function to get user role (SECURITY DEFINER prevents recursion)
CREATE OR REPLACE FUNCTION public.get_user_role(uid uuid)
RETURNS public.user_role
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT role FROM public.profiles WHERE id = uid;
$$;

-- Profiles RLS policies
CREATE POLICY "Admins have full access to profiles" ON public.profiles
  FOR ALL TO authenticated
  USING (get_user_role(auth.uid()) = 'admin'::public.user_role);

CREATE POLICY "Users can view their own profile" ON public.profiles
  FOR SELECT TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update their own profile" ON public.profiles
  FOR UPDATE TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (role IS NOT DISTINCT FROM get_user_role(auth.uid()));

-- Public profiles view
CREATE VIEW public.public_profiles AS
  SELECT id, role, display_name FROM public.profiles;

-- Trigger: sync new user to profiles
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email, phone, role)
  VALUES (
    NEW.id,
    NEW.email,
    NEW.raw_user_meta_data->>'phone',
    'user'::public.user_role
  );
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Auto-update updated_at
CREATE OR REPLACE FUNCTION public.update_updated_at()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE TRIGGER profiles_updated_at BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

-- Models table (static data)
CREATE TABLE public.models (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  provider text NOT NULL,
  category text NOT NULL,
  description text,
  tags text[] DEFAULT '{}',
  is_active boolean NOT NULL DEFAULT true,
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.models ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view active models" ON public.models
  FOR SELECT TO anon, authenticated
  USING (is_active = true);

CREATE POLICY "Admins manage models" ON public.models
  FOR ALL TO authenticated
  USING (get_user_role(auth.uid()) = 'admin'::public.user_role);

-- Model favorites
CREATE TABLE public.model_favorites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES public.profiles(id) ON DELETE CASCADE,
  model_id uuid NOT NULL REFERENCES public.models(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, model_id)
);

ALTER TABLE public.model_favorites ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users manage their own favorites" ON public.model_favorites
  FOR ALL TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins view all favorites" ON public.model_favorites
  FOR SELECT TO authenticated
  USING (get_user_role(auth.uid()) = 'admin'::public.user_role);

-- API keys
CREATE TABLE public.api_keys (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES public.profiles(id) ON DELETE CASCADE,
  name text NOT NULL,
  group_name text NOT NULL DEFAULT '默认分组',
  key_value text NOT NULL UNIQUE DEFAULT 'sk-' || encode(gen_random_bytes(24), 'hex'),
  quota_limit bigint, -- NULL means unlimited
  quota_used bigint NOT NULL DEFAULT 0,
  note text,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.api_keys ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users manage their own api_keys" ON public.api_keys
  FOR ALL TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins view all api_keys" ON public.api_keys
  FOR ALL TO authenticated
  USING (get_user_role(auth.uid()) = 'admin'::public.user_role);

CREATE TRIGGER api_keys_updated_at BEFORE UPDATE ON public.api_keys
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

-- Quota records
CREATE TABLE public.quota_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES public.profiles(id) ON DELETE CASCADE,
  api_key_id uuid REFERENCES public.api_keys(id) ON DELETE SET NULL,
  model_id uuid REFERENCES public.models(id) ON DELETE SET NULL,
  model_name text,
  amount numeric(12,4) NOT NULL DEFAULT 0.7,
  description text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.quota_records ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users view their own quota_records" ON public.quota_records
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users insert their own quota_records" ON public.quota_records
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins full access quota_records" ON public.quota_records
  FOR ALL TO authenticated
  USING (get_user_role(auth.uid()) = 'admin'::public.user_role);

-- API call logs
CREATE TABLE public.api_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES public.profiles(id) ON DELETE CASCADE,
  api_key_id uuid REFERENCES public.api_keys(id) ON DELETE SET NULL,
  api_key_name text,
  model_id uuid REFERENCES public.models(id) ON DELETE SET NULL,
  model_name text,
  request_summary text,
  response_status text NOT NULL DEFAULT 'success',
  quota_used numeric(12,4) NOT NULL DEFAULT 0.7,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.api_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users view their own api_logs" ON public.api_logs
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users insert their own api_logs" ON public.api_logs
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins full access api_logs" ON public.api_logs
  FOR ALL TO authenticated
  USING (get_user_role(auth.uid()) = 'admin'::public.user_role);

-- Seed models data
INSERT INTO public.models (name, provider, category, description, tags, sort_order) VALUES
('GPT-4o', 'OpenAI', '通用对话', 'OpenAI最新多模态大模型，支持文本、图像输入，推理能力强', ARRAY['多模态','推理','代码'], 1),
('GPT-4o mini', 'OpenAI', '通用对话', 'OpenAI轻量级模型，性价比高，速度快', ARRAY['轻量','快速','经济'], 2),
('GPT-4.1', 'OpenAI', '通用对话', 'GPT-4系列最新版本，综合能力卓越', ARRAY['推理','代码','创作'], 3),
('GPT-3.5 Turbo', 'OpenAI', '通用对话', '快速高效的对话模型，适合日常任务', ARRAY['快速','经济'], 4),
('o3', 'OpenAI', '推理模型', 'OpenAI最强推理模型，深度思考能力卓越', ARRAY['推理','数学','科学'], 5),
('o4-mini', 'OpenAI', '推理模型', '高效推理模型，在推理任务上表现出色', ARRAY['推理','快速'], 6),
('Claude 3.5 Sonnet', 'Anthropic', '通用对话', 'Anthropic旗舰模型，擅长长文本分析和代码生成', ARRAY['长文本','代码','分析'], 10),
('Claude 3.5 Haiku', 'Anthropic', '通用对话', 'Claude系列快速模型，轻量高效', ARRAY['快速','轻量'], 11),
('Claude 3 Opus', 'Anthropic', '通用对话', 'Anthropic最强综合能力模型', ARRAY['推理','创作','分析'], 12),
('Gemini 2.0 Flash', 'Google', '多模态', 'Google最快多模态模型，支持超长上下文', ARRAY['多模态','快速','长上下文'], 20),
('Gemini 1.5 Pro', 'Google', '多模态', 'Google旗舰多模态模型，百万token上下文', ARRAY['多模态','长上下文'], 21),
('Gemini 1.5 Flash', 'Google', '多模态', 'Google轻量级多模态模型', ARRAY['多模态','快速'], 22),
('文心一言 4.0', '百度', '国产模型', '百度旗舰大语言模型，中文理解能力强', ARRAY['中文','知识问答'], 30),
('文心一言 3.5', '百度', '国产模型', '百度轻量级语言模型，速度快成本低', ARRAY['中文','轻量'], 31),
('通义千问 Max', '阿里云', '国产模型', '阿里云旗舰大模型，综合能力强', ARRAY['中文','代码','多模态'], 32),
('通义千问 Plus', '阿里云', '国产模型', '阿里云均衡型大模型，性价比优秀', ARRAY['中文','均衡'], 33),
('通义千问 Turbo', '阿里云', '国产模型', '阿里云快速轻量模型', ARRAY['中文','快速'], 34),
('讯飞星火 3.5', '科大讯飞', '国产模型', '讯飞旗舰大模型，多模态理解能力强', ARRAY['中文','多模态','语音'], 40),
('智谱GLM-4', '智谱AI', '国产模型', '智谱AI旗舰大模型，代码和推理能力出色', ARRAY['中文','代码','推理'], 41),
('Kimi k1.5', 'Moonshot', '国产模型', 'Moonshot月之暗面旗舰推理模型', ARRAY['推理','长文本'], 42),
('DeepSeek-V3', 'DeepSeek', '国产模型', 'DeepSeek旗舰开源大模型，综合能力强', ARRAY['开源','代码','推理'], 43),
('DeepSeek-R1', 'DeepSeek', '推理模型', 'DeepSeek推理模型，数学和代码表现卓越', ARRAY['推理','数学','开源'], 44),
('Llama 3.1 405B', 'Meta', '开源模型', 'Meta最强开源模型，通用能力卓越', ARRAY['开源','通用'], 50),
('Llama 3.3 70B', 'Meta', '开源模型', 'Meta高效开源模型，性能优秀', ARRAY['开源','高效'], 51),
('Mixtral 8x7B', 'Mistral', '开源模型', 'Mistral混合专家开源模型', ARRAY['开源','混合专家'], 52),
('Grok-2', 'xAI', '通用对话', 'Elon Musk旗下xAI大模型，实时信息访问', ARRAY['实时信息','推理'], 60),
('Command R+', 'Cohere', '通用对话', 'Cohere企业级大模型，擅长RAG检索增强', ARRAY['企业','RAG'], 61),
('Yi-Large', '零一万物', '国产模型', '李开复团队打造的高性能大模型', ARRAY['中文','多语言'], 70),
('Qwen2.5-72B', '阿里云', '开源模型', '通义千问开源旗舰，综合能力出色', ARRAY['开源','中文','推理'], 71),
('MiniMax-M1', 'MiniMax', '国产模型', 'MiniMax旗舰大模型，长上下文处理能力强', ARRAY['长上下文','中文'], 72);

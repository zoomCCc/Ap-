# 小王工作室 ARl 公益站

> 连接全球AI大模型，免费注册即送 **1000万额度**

AI 大模型 API 统一管理平台，支持 GPT-4o、Claude 3.5 Sonnet、Gemini 2.0、文心一言、通义千问、DeepSeek 等 30+ 主流模型，提供 API 密钥管理、额度统计、调用日志等完整功能。

---

## ✨ 功能清单

| 模块 | 功能 |
|------|------|
| 注册/登录 | 邮箱OTP、手机OTP、邮箱+密码、手机+密码 四种方式 |
| 工作台 | 额度统计卡片、7日消耗趋势图、快捷操作入口 |
| 模型中心 | 30+ AI 模型列表、详情页、收藏、多模型对比（最多5个）|
| API 密钥 | 创建/编辑/删除密钥，支持分组、额度限制、备注 |
| 消耗明细 | 按日期/密钥筛选，分页查看额度消耗记录 |
| 调用日志 | 调用详情、状态、消耗额度，支持多维度筛选 |
| 数据统计 | 额度趋势、调用次数趋势、模型分布饼图、密钥分布饼图 |
| 个人信息 | 修改密码、修改邮箱（OTP验证）、修改手机号 |
| 用户管理 | 管理员专属：设置权限、调整额度、禁用/启用用户 |
| 设置 | 语言切换（中/英/日）、主题切换（浅色/深色/跟随系统）|

---

## 🚀 部署指南

### 第一步：配置环境变量

复制示例文件：

```bash
cp .env.example .env.local
```

填写 Supabase 信息（登录 [Supabase 控制台](https://supabase.com) → 项目 → Settings → API）：

```
VITE_SUPABASE_URL=https://xxxxxx.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

### 第二步：初始化数据库

在 Supabase 控制台 → SQL Editor 中，粘贴并执行 `supabase/migrations/00001_init_schema.sql` 的全部内容。
该脚本会自动创建所有表、RLS 策略、触发器，并插入 30+ 模型种子数据。

### 第三步：部署前端

#### 方式 A — Vercel（最简单）

1. 将代码推送到 GitHub
2. 登录 [Vercel](https://vercel.com) → Import Project
3. **Environment Variables** 中添加 `VITE_SUPABASE_URL` 和 `VITE_SUPABASE_ANON_KEY`
4. 点击 Deploy ✅

#### 方式 B — Netlify

1. 推送代码到 GitHub，登录 [Netlify](https://netlify.com) → New site
2. Build command: `npm run build` · Publish directory: `dist`
3. 添加环境变量，Deploy site ✅

#### 方式 C — 手动构建 + Nginx

```bash
npm install
npm run build          # 产物输出到 dist/
```

Nginx 配置（SPA 必须将所有路径重定向到 index.html）：

```nginx
server {
    listen 80;
    server_name your-domain.com;
    root /var/www/dist;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }
}
```

---

## 目录结构

```
src/
├── components/
│   ├── common/        # 公共组件（PageMeta、RouteGuard 等）
│   ├── layouts/       # AppLayout（响应式侧边栏布局）
│   └── ui/            # shadcn/ui 51 个组件
├── contexts/
│   ├── AppContext.tsx  # 语言/主题全局状态
│   └── AuthContext.tsx # 用户认证状态
├── db/
│   └── supabase.ts    # Supabase 客户端初始化
├── i18n/
│   └── index.ts       # 中/英/日 300+ 翻译词条
├── pages/             # 12 个功能页面
├── services/
│   └── api.ts         # 20+ 数据库操作封装函数
└── types/
    └── types.ts       # TypeScript 接口定义
supabase/
└── migrations/
    └── 00001_init_schema.sql  # 完整数据库初始化脚本
```

## 技术栈

| 类别 | 技术 |
|------|------|
| 框架 | React 18 + TypeScript |
| 构建 | Vite |
| 样式 | Tailwind CSS v3 + shadcn/ui |
| 字体 | Glow Sans SC |
| 图表 | Recharts |
| 后端 | Supabase（PostgreSQL + Auth + RLS）|
| 路由 | React Router v7 |

## 本地开发

### 环境要求

```
Node.js ≥ 20
pnpm（推荐）或 npm ≥ 10
```

### 启动步骤

```bash
# 1. 安装依赖
pnpm install   # 或 npm install

# 2. 配置环境变量
cp .env.example .env.local
# 编辑 .env.local，填入 Supabase URL 和 anon key

# 3. 启动开发服务器
pnpm dev   # 或 npm run dev -- --host 127.0.0.1
```

## 环境变量说明

| 变量名 | 必填 | 说明 |
|--------|------|------|
| `VITE_SUPABASE_URL` | ✅ | Supabase 项目 URL（在控制台 Settings → API 中查看）|
| `VITE_SUPABASE_ANON_KEY` | ✅ | Supabase 匿名公钥 anon key |
| `VITE_SENTRY_DSN` | ❌ | Sentry 错误监控（不填则关闭）|

## 了解更多

查看帮助文档：[源码导出](https://cloud.baidu.com/doc/MIAODA/s/Xmewgmsq7)，了解更多详细内容。
